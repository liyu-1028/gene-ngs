#!/usr/bin/env python3
"""Audit every gzip FASTQ member in a locally downloaded ScienceDB tar.

Checks the tar MD5, member names and MD5s, gzip CRC, four-line FASTQ framing,
200,000 reads per member, and 100-base sequence/quality lengths. Results are
written to a JSON summary and per-member TSV. This checks file integrity and
record linkage, not whether each claimed variant was actually simulated.
"""

import argparse
import csv
import gzip
import hashlib
import json
import tarfile
from pathlib import Path

import numpy as np


def hash_file(path: Path) -> tuple[str, str]:
    md5 = hashlib.md5()
    sha256 = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            md5.update(chunk)
            sha256.update(chunk)
    return md5.hexdigest(), sha256.hexdigest()


def read_manifest(path: Path) -> dict[str, str]:
    result = {}
    for line in path.read_text().splitlines():
        if line.startswith("#") or not line.strip():
            continue
        digest, name = line.split(None, 1)
        result[name.strip()] = digest.lower()
    return result


class HashingReader:
    def __init__(self, source):
        self.source = source
        self.md5 = hashlib.md5()

    def read(self, size=-1):
        data = self.source.read(size)
        self.md5.update(data)
        return data


def inspect_fastq(source) -> tuple[int, int, list[str], str]:
    raw = HashingReader(source)
    line_number = 0
    carry = b""
    errors = []
    try:
        with gzip.GzipFile(fileobj=raw) as fastq:
            while chunk := fastq.read(4 * 1024 * 1024):
                data = carry + chunk
                arr = np.frombuffer(data, dtype=np.uint8)
                ends = np.flatnonzero(arr == 10)
                if not len(ends):
                    carry = data
                    if len(carry) > 1024 * 1024:
                        errors.append("FASTQ line longer than 1 MiB")
                        break
                    continue
                starts = np.empty(len(ends), dtype=np.int64)
                starts[0] = 0
                starts[1:] = ends[:-1] + 1
                lengths = ends - starts
                kind = (np.arange(len(ends)) + line_number) % 4
                if np.any(arr[starts[kind == 0]] != 64):
                    errors.append("Header line does not start with @")
                if np.any(arr[starts[kind == 2]] != 43):
                    errors.append("Separator line does not start with +")
                if np.any(lengths[kind == 1] != 100):
                    errors.append("Sequence line length is not 100")
                if np.any(lengths[kind == 3] != 100):
                    errors.append("Quality line length is not 100")
                line_number += len(ends)
                carry = data[int(ends[-1]) + 1:]
        # Include any compressed bytes not consumed by GzipFile's final read.
        raw.read()
    except (OSError, EOFError) as exc:
        errors.append(f"gzip integrity failure: {exc}")
    if carry:
        errors.append("FASTQ ends without newline")
    if line_number % 4:
        errors.append("FASTQ line count is not divisible by four")
    return line_number // 4, line_number, sorted(set(errors)), raw.md5.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tar", required=True, type=Path)
    parser.add_argument("--mapping", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output-prefix", required=True, type=Path)
    parser.add_argument("--max-members", type=int, help="Only for a smoke test; not a full audit")
    args = parser.parse_args()

    with args.mapping.open(newline="") as handle:
        mapping = list(csv.DictReader(handle))
    expected = {row["fastq_filename"] for row in mapping}
    manifest = read_manifest(args.manifest)
    whole_md5, whole_sha256 = (None, None) if args.max_members else hash_file(args.tar)
    published_tar_md5 = manifest.get("zenodo_staging/synthetic_msk_impact_2017_reads.tar")
    rows = []
    with tarfile.open(args.tar, mode="r") as archive:
        for member in archive:
            if not member.isfile():
                rows.append({"name": member.name, "error": "non-file tar member"})
                continue
            source = archive.extractfile(member)
            if source is None:
                rows.append({"name": member.name, "error": "cannot extract member"})
                continue
            with source:
                reads, lines, errors, digest = inspect_fastq(source)
            published_md5 = manifest.get(f"synthetic_2017/reads/{member.name}")
            if published_md5 is None:
                errors.append("missing published member MD5")
            elif digest != published_md5:
                errors.append("member MD5 mismatch")
            if member.name not in expected:
                errors.append("member absent from V2 mapping")
            if reads != 200000:
                errors.append("read count is not 200000")
            rows.append({
                "name": member.name,
                "compressed_bytes": member.size,
                "md5": digest,
                "published_md5": published_md5 or "",
                "reads": reads,
                "lines": lines,
                "error": "; ".join(sorted(set(errors))),
            })
            if len(rows) % 100 == 0:
                print(f"Audited {len(rows)} FASTQ members", flush=True)
            if args.max_members and len(rows) >= args.max_members:
                break
    observed = [row["name"] for row in rows]
    full = args.max_members is None
    summary = {
        "archive": args.tar.name,
        "archive_bytes": args.tar.stat().st_size,
        "archive_md5": whole_md5,
        "archive_sha256": whole_sha256,
        "published_archive_md5": published_tar_md5,
        "archive_md5_match": whole_md5 == published_tar_md5 if full else None,
        "full_audit": full,
        "mapping_rows": len(mapping),
        "member_rows": len(rows),
        "unique_member_names": len(set(observed)),
        "missing_mapping_members": sorted(expected - set(observed)) if full else None,
        "unmapped_members": sorted(set(observed) - expected),
        "ordered_names_match": observed == [row["fastq_filename"] for row in mapping] if full else None,
        "members_with_errors": [row["name"] for row in rows if row["error"]],
        "all_members_200000_reads": all(row.get("reads") == 200000 for row in rows),
        "interpretation_limit": "No inference about the presence or VAF of individual spike-in variants.",
    }
    args.output_prefix.parent.mkdir(parents=True, exist_ok=True)
    summary_path = args.output_prefix.with_suffix(".json")
    detail_path = args.output_prefix.with_suffix(".tsv")
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n")
    with detail_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["name", "compressed_bytes", "md5", "published_md5", "reads", "lines", "error"], delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({key: value for key, value in summary.items() if key != "members_with_errors"}, indent=2))
    if summary["members_with_errors"] or (full and (not summary["archive_md5_match"] or summary["missing_mapping_members"] or not summary["ordered_names_match"])):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
