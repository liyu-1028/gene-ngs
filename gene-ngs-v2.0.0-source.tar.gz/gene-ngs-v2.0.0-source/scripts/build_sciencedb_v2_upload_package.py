#!/usr/bin/env python3
"""Build the small-file ScienceDB V2 upload set and a complete object manifest.

The unchanged 39-GB FASTQ tar is deliberately not copied into the workspace.
Its identity is taken from the independently verified retained-assets table.
"""

import csv
import hashlib
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = ROOT / "data/zenodo_staging_v2_pending"
OUTPUT = ROOT / "data/sciencedb_v2_upload_ready"
RENAME = {
    "README_V2_DRAFT.md": "README.md",
    "CHANGELOG_V1_TO_V2_DRAFT.md": "CHANGELOG_V1_TO_V2.md",
}
SKIP = {"MANIFEST_V2_PENDING.md5"}


def replace_once(text: str, old: str, new: str, name: str) -> str:
    if text.count(old) != 1:
        raise ValueError(f"Expected one instance of {old!r} in {name}")
    return text.replace(old, new)


def release_text(name: str, text: str) -> str:
    if name == "README.md":
        text = replace_once(text, " — V2 draft", " — V2", name)
        text = replace_once(text,
            "> Status: local preparation only; not uploaded. This draft must be reviewed before the V2 deposit is released.\n\n",
            "This README describes the V2 object set. Verify the repository version and checksums after download.\n\n", name)
        text = replace_once(text, "## V2 files prepared for addition", "## V2 files", name)
        text = replace_once(text, "CHANGELOG_V1_TO_V2_DRAFT.md", "CHANGELOG_V1_TO_V2.md", name)
        text = replace_once(text,
            "The final V2 version requires a separate fresh download check.",
            "Readers should verify the downloaded V2 object against the listed identity.", name)
        text = replace_once(text,
            "The current V2 staging directory is a local release candidate. The published V1 FASTQ tar",
            "The unchanged published V1 FASTQ tar", name)
        text = replace_once(text,
            " Do not cite this draft as a deposited V2 object.", "", name)
    elif name == "DATA_DICTIONARY_V2.md":
        text = replace_once(text, "# V2 data dictionary (release candidate)",
                            "# V2 data dictionary", name)
        text = replace_once(text,
            "This dictionary describes the files prepared for a ScienceDB V2 update. The version is not public until the repository issues it and the downloaded files pass independent checks.",
            "This dictionary describes the ScienceDB V2 files. Readers should check the downloaded version against the published manifest.", name)
        text = replace_once(text,
            "the V2 release must expose the same bytes and be downloaded again for final version verification.",
            "the retained V2 tar should match the same bytes.", name)
        text = replace_once(text,
            "`MANIFEST_V2_PENDING.md5` lists each local candidate file by path relative to this directory. It does not yet cover the FASTQ tar or the unchanged V1 CSV and is **not** a final public-version manifest.",
            "`MANIFEST_V2.md5` lists the MD5 of every intended V2 object, including the unchanged CSV and FASTQ tar, by path relative to this directory. Downloaded objects should be checked against it.", name)
    elif name == "CHANGELOG_V1_TO_V2.md":
        text = replace_once(text, "# V1 to V2 change log (draft; V2 not deposited)",
                            "# V1 to V2 change log", name)
        text = replace_once(text, "## Added objects prepared locally", "## Added V2 objects", name)
        text = replace_once(text, "## Remaining release gates", "## Verification after download", name)
        text = replace_once(text,
            "Publish an accessible frozen code snapshot and one coherent V2 package, then download that exact version anonymously and verify its manifest before replacing the manuscript's pending-state wording.",
            "The V2 package should be downloaded anonymously and checked against its manifest. The public GitHub repository requires a fixed release containing the corrected analysis code before the manuscript can claim code-version closure.", name)
    elif name == "figure_data/README.md":
        text = replace_once(text, "# Figure data selection for the V2 candidate",
                            "# Figure data selection for V2", name)
    return text


def md5(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError(f"Refusing to overwrite existing output: {OUTPUT}")
    OUTPUT.mkdir(parents=True)
    for source in sorted(CANDIDATE.rglob("*")):
        if not source.is_file():
            continue
        relative = source.relative_to(CANDIDATE).as_posix()
        if relative in SKIP:
            continue
        final_name = RENAME.get(relative, relative)
        target = OUTPUT / final_name
        target.parent.mkdir(parents=True, exist_ok=True)
        if source.suffix == ".md":
            target.write_text(release_text(final_name, source.read_text(encoding="utf-8")),
                              encoding="utf-8")
        else:
            shutil.copyfile(source, target)
    for name in ("synthetic_msk_impact_2017_cohort.csv",
                 "tv_2017_statistical_fidelity.json"):
        shutil.copyfile(ROOT / "data/zenodo_staging" / name, OUTPUT / name)
    with (CANDIDATE / "V2_RETAINED_CORE_ASSETS.tsv").open(newline="") as stream:
        retained = {row["required_v2_filename"]: row
                    for row in csv.DictReader(stream, delimiter="\t")}
    lines = [f"{md5(path)}  {path.relative_to(OUTPUT).as_posix()}"
             for path in sorted(OUTPUT.rglob("*")) if path.is_file()]
    lines.append(f"{retained['synthetic_msk_impact_2017_reads.tar']['md5']}  "
                 "synthetic_msk_impact_2017_reads.tar")
    (OUTPUT / "MANIFEST_V2.md5").write_text("\n".join(sorted(lines)) + "\n")
    for name in ("synthetic_msk_impact_2017_cohort.csv",
                 "tv_2017_statistical_fidelity.json"):
        if md5(OUTPUT / name) != retained[name]["md5"]:
            raise ValueError(f"Retained V1 identity mismatch: {name}")
    print(f"Prepared {len(lines)} manifest entries and the manifest itself in {OUTPUT}")
    print("Retain the unchanged public FASTQ tar in V2; do not upload a symlink or placeholder.")


if __name__ == "__main__":
    main()
