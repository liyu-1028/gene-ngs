#!/usr/bin/env python3
"""Run deterministic structural checks on the LaTeX manuscript."""

from __future__ import annotations

import re
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
MANUSCRIPT = ROOT / "paper/main.tex"


def uncomment(text: str) -> str:
    """Remove LaTeX comments while preserving escaped percent signs."""
    lines = []
    for line in text.splitlines():
        cut = len(line)
        for match in re.finditer(r"%", line):
            backslashes = 0
            position = match.start() - 1
            while position >= 0 and line[position] == "\\":
                backslashes += 1
                position -= 1
            if backslashes % 2 == 0:
                cut = match.start()
                break
        lines.append(line[:cut])
    return "\n".join(lines)


def words(latex: str) -> list[str]:
    text = re.sub(r"\\[A-Za-z]+(?:\{\})?", " ", latex)
    text = re.sub(r"[^A-Za-z0-9'-]+", " ", text)
    return text.split()


raw = MANUSCRIPT.read_text(encoding="utf-8")
for table_path in sorted((MANUSCRIPT.parent / "tables").glob("table_*.tex")):
    include = rf"\input{{tables/{table_path.stem}}}"
    if include in raw:
        raw = raw.replace(include, table_path.read_text(encoding="utf-8"))
text = uncomment(raw)
failures: list[str] = []

title_match = re.search(r"\\title\{([^}]*)\}", text, re.DOTALL)
abstract_match = re.search(
    r"\\begin\{abstract\}(.*?)\\end\{abstract\}", text, re.DOTALL
)
if title_match is None:
    failures.append("missing title")
    title = ""
else:
    title = " ".join(title_match.group(1).split())
    if len(title) > 110:
        failures.append(f"title has {len(title)} characters (limit 110)")
    if ":" in title or "(" in title or ")" in title:
        failures.append("title contains a colon or parentheses")

if abstract_match is None:
    failures.append("missing abstract")
    abstract_word_count = 0
else:
    abstract_word_count = len(words(abstract_match.group(1)))
    if abstract_word_count > 170:
        failures.append(f"abstract has {abstract_word_count} words (limit 170)")
    if re.search(r"(?:https?://|\\url\{)", abstract_match.group(1)):
        failures.append("abstract contains a URL")

required_sections = [
    "Background \\& Summary",
    "Methods",
    "Data Records",
    "Technical Validation",
    "Usage Notes",
    "Data Availability",
    "Code Availability",
    "Author Contributions",
    "Competing Interests",
]
for section in required_sections:
    if f"\\section*{{{section}}}" not in text:
        failures.append(f"missing required section: {section}")

environment_counts: dict[str, tuple[int, int]] = {}
for environment in ("document", "abstract", "figure", "table", "longtable", "tabular"):
    starts = len(re.findall(rf"\\begin\{{{environment}\}}", text))
    ends = len(re.findall(rf"\\end\{{{environment}\}}", text))
    environment_counts[environment] = (starts, ends)
    if starts != ends:
        failures.append(f"unbalanced {environment}: {starts} begin, {ends} end")

figure_count = environment_counts["figure"][0]
table_count = environment_counts["table"][0] + environment_counts["longtable"][0]
if figure_count != 5:
    failures.append(f"expected 5 figures, found {figure_count}")
if figure_count > 8:
    failures.append(f"found {figure_count} figures (journal recommendation: no more than 8)")
if table_count != 6:
    failures.append(f"expected 6 tables, found {table_count}")

graphics = re.findall(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}", text)
for graphic in graphics:
    graphic_path = MANUSCRIPT.parent / graphic
    if not graphic_path.is_file():
        failures.append(f"included graphic does not exist: {graphic}")

if r"\footnote{" in text:
    failures.append("ordinary footnotes are not permitted by the journal guide")

code_availability_position = text.find(r"\section*{Code Availability}")
bibliography_position = text.find(r"\begin{thebibliography}")
if code_availability_position < 0 or bibliography_position < 0:
    failures.append("cannot verify Code Availability placement before references")
elif code_availability_position > bibliography_position:
    failures.append("Code Availability must appear before references")

cites = []
for group in re.findall(r"\\cite\{([^}]+)\}", text):
    cites.extend(item.strip() for item in group.split(","))
bibliography = re.findall(r"\\bibitem\{([^}]+)\}", text)
missing_bibliography = sorted(set(cites) - set(bibliography))
uncited_bibliography = sorted(set(bibliography) - set(cites))
if missing_bibliography:
    failures.append(f"citations without bibliography entries: {missing_bibliography}")
if uncited_bibliography:
    failures.append(f"bibliography entries not cited: {uncited_bibliography}")

labels = re.findall(r"\\label\{([^}]+)\}", text)
references = re.findall(r"\\ref\{([^}]+)\}", text)
duplicate_labels = sorted(label for label, count in Counter(labels).items() if count > 1)
missing_labels = sorted(set(references) - set(labels))
if duplicate_labels:
    failures.append(f"duplicate labels: {duplicate_labels}")
if missing_labels:
    failures.append(f"references without labels: {missing_labels}")

truth_status_sentence = (
    "Per-patient spike-in input provenance has been prepared for a repository update "
    "but is not included in public V1."
)
if truth_status_sentence not in text:
    failures.append("per-patient truth availability statement is absent")
if "Per-patient spike-in truth sets are provided with the deposit." in text:
    failures.append("truth sets are described as deposited before repository verification")

required_author_and_funding_fragments = [
    r"Yanlong LI$^{1}$",
    r"Zhangyi Shen$^{2,*}$",
    "School of Computer and Information, Anhui Normal University, Wuhu, China",
    "School of Intelligent Information and Advanced Manufacturing",
    "Corresponding email: shenzhangyi@ahnu.edu.cn",
    "GXXT-2022-054",
    "2023GFXK180",
]
for fragment in required_author_and_funding_fragments:
    if fragment not in text:
        failures.append(f"required author/funding text is absent: {fragment}")

if text.count("50K") != 1:
    failures.append(f"rendered manuscript must contain one 50K mention, found {text.count('50K')}")
for phrase in ("privacy-safe", "same manifold", "physically faithful", "unbiased"):
    if phrase.lower() in text.lower():
        failures.append(f"forbidden overclaim present: {phrase}")

non_ascii_cjk = [character for character in text if "\u3400" <= character <= "\u9fff"]
if non_ascii_cjk:
    failures.append("CJK glyphs remain in pdfLaTeX source; use code points or configure fonts")

# A lightweight brace check catches accidental structural damage outside comments.
depth = 0
escaped = False
for character in text:
    if escaped:
        escaped = False
        continue
    if character == "\\":
        escaped = True
    elif character == "{":
        depth += 1
    elif character == "}":
        depth -= 1
        if depth < 0:
            failures.append("closing brace without matching opening brace")
            break
if depth != 0:
    failures.append(f"unbalanced braces: final depth {depth}")

metadata_placeholders = len(re.findall(r"\\placeholder\{", text))
figure_placeholders = len(re.findall(r"\\figplaceholder\{", text))
if figure_placeholders:
    failures.append(f"Stage 8 manuscript still contains {figure_placeholders} figure placeholders")
if len(graphics) + figure_placeholders != figure_count:
    failures.append(
        "figure environments are not matched by included graphics or placeholders: "
        f"{len(graphics)} graphics + {figure_placeholders} placeholders != {figure_count} figures"
    )
print(f"Title: {len(title)} characters")
print(f"Abstract: {abstract_word_count} words")
print(f"Figures: {figure_count}; tables: {table_count}")
print(f"Citations: {len(set(cites))}; bibliography entries: {len(bibliography)}")
print(
    f"Intentional unresolved placeholders: {metadata_placeholders} metadata, "
    f"{figure_placeholders} figures"
)
print(f"Existing included graphics: {len(graphics)}")

if failures:
    print("\nFAILED:")
    for failure in failures:
        print(f"  {failure}")
    sys.exit(1)

print("OK — manuscript structure and local graphic checks passed.")
