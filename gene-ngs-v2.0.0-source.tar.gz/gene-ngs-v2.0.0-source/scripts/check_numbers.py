#!/usr/bin/env python3
"""Verify manuscript macros against deposited JSONs and archived local evidence.

Usage:  python3 scripts/check_numbers.py
Exit code 0 = all numbers verified; 1 = any mismatch (stale number in manuscript).

Ground-truth sources:
  data/zenodo_staging/tv_*.json
  data/synthetic_2017/evaluation/*_summary.json
  github_export/gene-ngs/evaluation/mia_control_results.json
  data/synthetic_2017/evaluation/v2_quick_reanalysis/quick_reanalysis_results.json
  data/zenodo_staging_v2_pending/fastq_truth_summary.json
  released/local CSVs, the 2017 audit log, manifest, and simulation script

When a passing full FASTQ archive audit exists, the tar byte count and MD5 are
checked against that independently downloaded object. Otherwise the byte count
remains explicitly unchecked and the MD5 is checked only against the V1 manifest.
"""
import json
import re
import sys
import csv
import ast
import hashlib
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NUMBERS = ROOT / "paper/numbers.tex"

TV = ROOT / "data/zenodo_staging"
EV = ROOT / "data/synthetic_2017/evaluation"
GH = ROOT / "github_export/gene-ngs/evaluation"


def load(p):
    return json.loads(Path(p).read_text())


def csv_shape(p):
    """Return (data rows, columns) without loading a large CSV into memory."""
    with Path(p).open(newline="", encoding="utf-8") as f:
        rows = csv.reader(f)
        header = next(rows)
        return sum(1 for _ in rows), len(header)


sf17 = load(TV / "tv_2017_statistical_fidelity.json")
sf50 = load(TV / "tv_50k_statistical_fidelity.json")
tstr17 = load(TV / "tv_2017_tstr_utility.json")
tstr50 = load(TV / "tv_50k_tstr_utility.json")
pr17 = load(TV / "tv_2017_privacy.json")["Privacy_Assessment"]
pr50 = load(TV / "tv_50k_privacy.json")["Privacy_Assessment"]
mini = load(EV / "hicov_minisim/summary.json")
hicov = load(EV / "hicov_anchor_detail_summary.json")
agg = load(EV / "aggregate_anchor_detail_summary.json")
mia = load(GH / "mia_control_results.json")["results"]
v2 = load(EV / "v2_quick_reanalysis/quick_reanalysis_results.json")
truth_v2 = load(ROOT / "data/zenodo_staging_v2_pending/fastq_truth_summary.json")
delivery_correction = load(ROOT / "data/zenodo_staging_v2_pending/delivery_anchor_correction.json")
archive_report_path = ROOT / "manuscript_workbench/v2/FASTQ_ARCHIVE_AUDIT.json"
archive_report = load(archive_report_path) if archive_report_path.exists() else None
if archive_report and not (archive_report.get("full_audit") is True and
                           archive_report.get("archive_md5_match") is True and
                           archive_report.get("member_rows") == 2000 and
                           not archive_report.get("members_with_errors")):
    raise RuntimeError("FASTQ archive audit exists but is not a full pass")
conversion17 = load(ROOT / "data/real/msk_impact_2017/CONVERSION_REPORT.json")

raw17_rows, _ = csv_shape(ROOT / "data/synthetic_2017/raw_synthetic_data.csv")
released17_rows, released17_cols = csv_shape(
    ROOT / "data/zenodo_staging/synthetic_msk_impact_2017_cohort.csv")
released50_rows, _ = csv_shape(
    ROOT / "data/zenodo_staging_50k_hold/synthetic_msk_impact_50k_cohort.csv")

released17_path = TV / "synthetic_msk_impact_2017_cohort.csv"
released17_variant_count = 0
released17_empty_variant_lists = 0
with released17_path.open(newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        variants = ast.literal_eval(row["somatic_variants"])
        released17_variant_count += len(variants)
        released17_empty_variant_lists += not variants

truth_path = ROOT / "data/zenodo_staging_v2_pending/fastq_spikein_truth.tsv"
with truth_path.open(newline="", encoding="utf-8") as f:
    truth_rows = list(csv.DictReader(f, delimiter="\t"))
truth_patient_ids = {row["virtual_patient_id"] for row in truth_rows}

delivery_tsv = ROOT / "manuscript_workbench/v2/figure_data/fig6b_delivery_observability.tsv"
with delivery_tsv.open(newline="", encoding="utf-8") as f:
    delivery_counts = {row["observability_level"]: int(row["count"])
                       for row in csv.DictReader(f, delimiter="\t")}

simulation_log = (ROOT / "data/synthetic_2017/simulation.log").read_text(errors="replace")
simulation_indel_errors = simulation_log.count(
    "the specified small deletion is not compatible with the reference genome"
)

audit17 = load(ROOT / "data/synthetic_2017/audit_log.json")
audit17_counts = Counter((r["stage"], r["status"]) for r in audit17)
audit17_llm_error_rejects = sum(
    r.get("stage") == "LLM"
    and r.get("status") == "REJECT"
    and str(r.get("reason", "")).startswith("LLM Error:")
    for r in audit17
)
audit17_llm_content_rejects = (
    audit17_counts[("LLM", "REJECT")] - audit17_llm_error_rejects
)

manifest_rows = []
for line in (TV / "MANIFEST.md5").read_text().splitlines():
    if line and not line.startswith("#"):
        digest, path = line.split(None, 1)
        manifest_rows.append((digest, path))
manifest_fastqs = {
    path for _, path in manifest_rows
    if re.fullmatch(r"synthetic_2017/reads/virtual_pt_\d{4}\.fastq\.gz", path)
}
manifest_tar_hashes = {
    digest for digest, path in manifest_rows
    if path == "zenodo_staging/synthetic_msk_impact_2017_reads.tar"
}

simulation_script = (ROOT / "data/synthetic_2017/run_simulation.sh").read_text()
nreads_match = re.search(r"\bnreads=(\d+)", simulation_script)
seed_match = re.search(r"SEED=\$\(\((\d+) \+ i\)\)", simulation_script)
if not nreads_match or not seed_match:
    raise RuntimeError("Could not recover nreads/seed from the archived simulation script")
simulation_nreads = int(nreads_match.group(1))
simulation_seed_base = int(seed_match.group(1))

# expected: macro name -> (numeric value, tolerance)
exp = {
    # cohort flow and released files
    "NcandA": (raw17_rows, 0),
    "NsourcePatientsA": (conversion17["rows_patients"], 0),
    "NsourceVariantsA": (conversion17["variants_total"], 0),
    "NsourceSnvIndelA": (conversion17["variants_snv_indel"], 0),
    "NsourceFusionA": (conversion17["variants_fusion"], 0),
    "NsourceCnaA": (conversion17["variants_cna"], 0),
    "NsynA": (released17_rows, 0),
    "NcsvFieldsA": (released17_cols, 0),
    "NtableVariantsA": (released17_variant_count, 0),
    "NemptyVariantListsA": (released17_empty_variant_lists, 0),
    "NrejA": (audit17_counts[("LLM", "REJECT")], 0),
    "NllmContentRejectA": (audit17_llm_content_rejects, 0),
    "NllmErrorRejectA": (audit17_llm_error_rejects, 0),
    "NllmA": (audit17_counts[("LLM", "PASS")] + audit17_counts[("LLM", "REJECT")], 0),
    "NllmPassedA": (audit17_counts[("LLM", "PASS")], 0),
    "NhardRuleOnlyA": (audit17_counts[("HardRuleOnly", "PASS")], 0),
    "LlmRejRateA": (100 * audit17_counts[("LLM", "REJECT")] /
                     (audit17_counts[("LLM", "PASS")] + audit17_counts[("LLM", "REJECT")]), 0.05),
    "NsynB": (released50_rows, 0),
    "NfastqReleased": (len(manifest_fastqs), 0),
    "NreadsPerPatient": (simulation_nreads, 0),
    "SeedBase": (simulation_seed_base, 0),
    "NspecFiles": (3 * truth_v2["n_virtual_patients"], 0),
    "NsimIndelErrors": (simulation_indel_errors, 0),
    # statistical fidelity 2017
    "KStmbA": (sf17["Univariate_Marginal_Similarity"]["biomarkers.tmb"]["KS_statistic"], 0),
    "TVDgenderA": (sf17["Univariate_Marginal_Similarity"]["patient_info.gender"]["TVD"], 0),
    "GeneFreqDiffA": (sf17["Somatic_Variant_Fidelity"]["Average_Gene_Frequency_Difference"], 0),
    "TVDtpFiftyThreeA": (sf17["Somatic_Variant_Fidelity"]["Top_Gene_Differences"]["TP53"]["Frequency_Difference_TVD"], 0),
    "FreqTPrealA": (sf17["Somatic_Variant_Fidelity"]["Top_Gene_Differences"]["TP53"]["Real_Frequency"], 0),
    "FreqTPsynA": (sf17["Somatic_Variant_Fidelity"]["Top_Gene_Differences"]["TP53"]["Synthetic_Frequency"], 0),
    # statistical fidelity 50K
    "KSageB": (sf50["Univariate_Marginal_Similarity"]["patient_info.age"]["KS_statistic"], 0),
    "KStmbB": (sf50["Univariate_Marginal_Similarity"]["biomarkers.tmb"]["KS_statistic"], 0),
    "TVDgenderB": (sf50["Univariate_Marginal_Similarity"]["patient_info.gender"]["TVD"], 0),
    "TVDmsiB": (sf50["Univariate_Marginal_Similarity"]["biomarkers.msi"]["TVD"], 0),
    "PearsonMAEB": (sf50["Bivariate_Correlation"]["Pearson_MAE"], 0),
    "GeneFreqDiffB": (sf50["Somatic_Variant_Fidelity"]["Average_Gene_Frequency_Difference"], 0),
    "TVDtpFiftyThreeB": (sf50["Somatic_Variant_Fidelity"]["Top_Gene_Differences"]["TP53"]["Frequency_Difference_TVD"], 0),
    # corrected TSTR 2017 (10 repeated, leakage-controlled splits)
    "TRTRaurocA": (v2["C04_tstr"]["trtr_auroc"]["mean"], 5e-5),
    "TRTRfA": (v2["C04_tstr"]["trtr_f1"]["mean"], 5e-5),
    "TSTRaurocA": (v2["C04_tstr"]["tstr_auroc"]["mean"], 5e-5),
    "TSTRfA": (v2["C04_tstr"]["tstr_f1"]["mean"], 5e-5),
    "DeltaAurocA": (v2["C04_tstr"]["trtr_auroc"]["mean"] -
                     v2["C04_tstr"]["tstr_auroc"]["mean"], 5e-5),
    "TRTRaurocALow": (v2["C04_tstr"]["trtr_auroc"]["empirical_95pct_interval"][0], 5e-5),
    "TRTRaurocAHigh": (v2["C04_tstr"]["trtr_auroc"]["empirical_95pct_interval"][1], 5e-5),
    "TSTRaurocALow": (v2["C04_tstr"]["tstr_auroc"]["empirical_95pct_interval"][0], 5e-5),
    "TSTRaurocAHigh": (v2["C04_tstr"]["tstr_auroc"]["empirical_95pct_interval"][1], 5e-5),
    "TRTRfALow": (v2["C04_tstr"]["trtr_f1"]["empirical_95pct_interval"][0], 5e-5),
    "TRTRfAHigh": (v2["C04_tstr"]["trtr_f1"]["empirical_95pct_interval"][1], 5e-5),
    "TSTRfALow": (v2["C04_tstr"]["tstr_f1"]["empirical_95pct_interval"][0], 5e-5),
    "TSTRfAHigh": (v2["C04_tstr"]["tstr_f1"]["empirical_95pct_interval"][1], 5e-5),
    "RealPositiveRateA": (100 * v2["C04_tstr"]["real_positive_rate"], 0.005),
    "SyntheticPositiveRateA": (100 * v2["C04_tstr"]["synthetic_positive_rate"], 0.005),
    "ShapRhoA": (tstr17["Explainability"]["SHAP_Rank_Correlation"], 0),
    "ShapPA": (tstr17["Explainability"]["p_value"], 5e-5),
    # TSTR 50K
    "TRTRaurocB": (tstr50["Performance"]["TRTR"]["AUROC"], 0),
    "TRTRfB": (tstr50["Performance"]["TRTR"]["F1"], 0),
    "TSTRaurocB": (tstr50["Performance"]["TSTR"]["AUROC"], 0),
    "TSTRfB": (tstr50["Performance"]["TSTR"]["F1"], 0),
    "DeltaAurocB": (tstr50["Performance"]["Delta_AUROC"], 0),
    "ShapRhoB": (tstr50["Explainability"]["SHAP_Rank_Correlation"], 0),
    "ShapPB": (tstr50["Explainability"]["p_value"], 5e-5),
    # corrected privacy / distinguishability diagnostics 2017
    "DcrMedianA": (v2["C01_dcr_nndr"]["synthetic_to_distinct_real_dcr"]["median"], 5e-5),
    "DcrThresholdA": (v2["C01_dcr_nndr"]["positive_distinct_real_to_real_dcr"]
                       ["fifth_percentile_threshold"], 5e-7),
    "DcrLeakA": (100 * v2["C01_dcr_nndr"]["synthetic_to_distinct_real_dcr"]
                  ["below_positive_real_fifth_percentile_rate"], 0.005),
    "DcrLeakALow": (100 * v2["C01_dcr_nndr"]["synthetic_to_distinct_real_dcr"]
                     ["wilson_95pct_interval"][0], 0.005),
    "DcrLeakAHigh": (100 * v2["C01_dcr_nndr"]["synthetic_to_distinct_real_dcr"]
                      ["wilson_95pct_interval"][1], 0.005),
    "DcrExactZeroA": (v2["C01_dcr_nndr"]["synthetic_to_distinct_real_dcr"]["exact_zero_count"], 0),
    "NndrMedianA": (v2["C01_dcr_nndr"]["synthetic_nndr"]["median"], 5e-5),
    "MiaAccA": (v2["C03_discriminator"]["accuracy"]["mean"], 5e-5),
    "MiaFA": (v2["C03_discriminator"]["f1"]["mean"], 5e-5),
    "DiscAurocA": (v2["C03_discriminator"]["auroc"]["mean"], 5e-5),
    "ExactMatchA": (v2["C02_exact_match"]["shared_clinical_plus_complete_variant_list"]
                     ["matched_synthetic_rows"], 0),
    "FeatMatchA": (v2["C02_exact_match"]["shared_clinical_only"]["matched_synthetic_rows"], 0),
    "VariantListMatchA": (v2["C02_exact_match"]["complete_variant_list_only"]
                           ["matched_synthetic_rows"], 0),
    "FeatMatchRateA": (100 * v2["C02_exact_match"]["shared_clinical_only"]
                        ["synthetic_row_rate"], 0.0005),
    "VariantListMatchRateA": (100 * v2["C02_exact_match"]["complete_variant_list_only"]
                               ["synthetic_row_rate"], 0.0005),
    "ExactMatchRateA": (100 * v2["C02_exact_match"]
                         ["shared_clinical_plus_complete_variant_list"]
                         ["synthetic_row_rate"], 0.000005),
    "NdistinctRealA": (v2["C01_dcr_nndr"]["n_distinct_real_feature_vectors"], 0),
    "NDcrBelowA": (v2["C01_dcr_nndr"]["synthetic_to_distinct_real_dcr"]
                    ["below_positive_real_fifth_percentile_count"], 0),
    "DiscAccLowA": (v2["C03_discriminator"]["accuracy"]["empirical_95pct_interval"][0], 5e-5),
    "DiscAccHighA": (v2["C03_discriminator"]["accuracy"]["empirical_95pct_interval"][1], 5e-5),
    "DiscFLowA": (v2["C03_discriminator"]["f1"]["empirical_95pct_interval"][0], 5e-5),
    "DiscFHighA": (v2["C03_discriminator"]["f1"]["empirical_95pct_interval"][1], 5e-5),
    "DiscAurocLowA": (v2["C03_discriminator"]["auroc"]["empirical_95pct_interval"][0], 5e-5),
    "DiscAurocHighA": (v2["C03_discriminator"]["auroc"]["empirical_95pct_interval"][1], 5e-5),
    # privacy 50K
    "DcrMedianB": (pr50["Distance_to_Closest_Record"]["Median_Cross_Set_DCR"], 0),
    "DcrLeakB": (pr50["Distance_to_Closest_Record"]["Privacy_Leakage_Rate"], 0),
    "MiaAccB": (pr50["Membership_Inference_Attack"]["Attacker_Accuracy"], 0),
    "MiaFB": (pr50["Membership_Inference_Attack"]["Attacker_F1_Score"], 0),
    "ExactMatchB": (pr50["Exact_Match"]["Record_Level_Matches"], 0),
    "FeatMatchB": (pr50["Exact_Match"]["Feature_Level_Matches"], 0),
    # MIA control
    "MiaCtrlRzero": (mia["R0_real_vs_syn"]["acc"], 0),
    "MiaCtrlRzeroF": (mia["R0_real_vs_syn"]["f1"], 0),
    "MiaCtrlCone": (mia["C1_realA_vs_realB"]["acc"], 0),
    "MiaCtrlCtwo": (mia["C2_synA_vs_synB"]["acc"], 0),
    "MiaCtrlCthreeMin": (min(mia["C3_real_halves_multiseed"]), 0),
    "MiaCtrlCthreeMax": (max(mia["C3_real_halves_multiseed"]), 0),
    # anchor study 0.2x
    "AggAnchorsA": (agg["anchors"], 0),
    "AggCoveredAnchorsA": (delivery_counts["locus covered"], 0),
    "AggAltDetectedAnchorsA": (delivery_counts["ALT detected"], 0),
    "AggPatientsA": (agg["patients_sampled"], 0),
    "AggCoverA": (agg["locus_cover_rate"] * 100, 0.05),
    "AggAltDetA": (agg["alt_detectability"] * 100, 0.005),
    "AggSpearmanMag": (abs(agg["vaf_spearman_rho"]), 0),  # sign stated in prose
    "AggSpearmanP": (agg["vaf_p"], 5e-5),
    "AggGeTwoA": (agg["anchors_with_ge2_reads"], 0),
    "DeliveryNoChangeFallback": (delivery_correction["covered_reference_equals_alt_fallback_rows_excluded"], 0),
    "DeliveryValidCovered": (delivery_correction["covered_valid_reference_alt_rows"], 0),
    "DeliveryValidAlt": (delivery_correction["alt_positive_valid_reference_alt_rows"], 0),
    "DeliveryExactCovered": (delivery_correction["covered_exact_snv_rows"], 0),
    "DeliveryExactAll": (delivery_correction["all_exact_snv_anchor_rows"], 0),
    "DeliveryExactAlt": (delivery_correction["alt_positive_exact_snv_rows"], 0),
    "DeliveryExactGeTwo": (delivery_correction["depth_ge2_exact_snv_rows"], 0),
    "DeliveryExactGeTwoAlt": (5, 0),
    "DeliveryExactRho": (delivery_correction["depth_ge2_exact_snv_target_observed_spearman_rho"], 0.0005),
    "DeliveryExactP": (delivery_correction["depth_ge2_exact_snv_target_observed_spearman_p"], 0.00005),
    "FallbackNoChangeLoci": (97, 0),
    "FallbackNoChangeRows": (1074, 0),
    # hicov ~5x
    "HicovPatients": (hicov["patients_sampled"], 0),
    "HicovAnchors": (hicov["anchors"], 0),
    "HicovCover": (hicov["locus_cover_rate"] * 100, 0.005),
    "HicovAltDet": (hicov["alt_detectability"] * 100, 0.005),
    "HicovAnchorsGeTwo": (hicov["anchors_with_ge2_reads"], 0),
    "HicovRho": (hicov["vaf_spearman_rho"], 0),
    "HicovP": (hicov["vaf_p"], 5e-5),
    # mini-sim
    "MiniAnchors": (mini["n_anchors"], 0),
    "MiniTargetDepth": (mini["target_depth"], 0),
    "MiniMedianDepth": (mini["median_depth"], 0),
    "MiniCover": (mini["coverage_rate"] * 100, 0.005),
    "MiniAltDet": (mini["alt_detected_rate"] * 100, 0.005),
    "MiniPearsonR": (mini["pearson_r"], 0),
    "MiniSpearman": (mini["spearman_rho"], 0),
    "MiniMadTc": (mini["mean_abs_dev_vs_tc"], 0),
    "TcValue": (mini["tc"], 0),
    # corrected exact-SNV mini-sim primary analysis
    "MiniExactAnchors": (v2["C05_minisim"]["primary_exact_snv_loci"]["n_rows"], 0),
    "MiniExactAltDetected": (v2["C05_minisim"]["primary_exact_snv_loci"]["n_alt_detected"], 0),
    "MiniExactPearsonR": (v2["C05_minisim"]["primary_exact_snv_loci"]["pearson_r"], 5e-5),
    "MiniExactSpearman": (v2["C05_minisim"]["primary_exact_snv_loci"]["spearman_rho"], 5e-5),
    "MiniExactSlope": (v2["C05_minisim"]["primary_exact_snv_loci"]["slope"], 5e-5),
    "MiniExactSlopeLow": (v2["C05_minisim"]["primary_exact_snv_loci"]
                           ["slope_95pct_interval"][0], 5e-5),
    "MiniExactSlopeHigh": (v2["C05_minisim"]["primary_exact_snv_loci"]
                            ["slope_95pct_interval"][1], 5e-5),
    "MiniExactBias": (v2["C05_minisim"]["primary_exact_snv_loci"]
                       ["mean_signed_observed_minus_target"], 5e-6),
    "MiniExactBiasLow": (v2["C05_minisim"]["primary_exact_snv_loci"]
                          ["mean_signed_bias_95pct_interval"][0], 5e-6),
    "MiniExactBiasHigh": (v2["C05_minisim"]["primary_exact_snv_loci"]
                           ["mean_signed_bias_95pct_interval"][1], 5e-6),
    "MiniExactMae": (v2["C05_minisim"]["primary_exact_snv_loci"]["mean_absolute_error"], 5e-6),
    # V2 mapping / truth metadata
    "NtruthVariants": (truth_v2["n_input_variants"], 0),
    "NtruthVirtualPatients": (truth_v2["n_virtual_patients"], 0),
    "NtruthPatientsWithVariants": (len(truth_patient_ids), 0),
    "NtruthExactSnv": (truth_v2["conversion_class_counts"]["exact_snv"], 0),
    "NtruthFallbackPm": (truth_v2["conversion_class_counts"]["gene_fallback_pm"], 0),
    "NtruthCna": (truth_v2["conversion_class_counts"]["amplification_cna"], 0),
    "NtruthIndel": (truth_v2["conversion_class_counts"]["heuristic_indel"], 0),
    "NtruthDropped": (truth_v2["conversion_class_counts"]["dropped_unmapped"], 0),
    "PtruthExactSnv": (100 * truth_v2["conversion_class_counts"]["exact_snv"] /
                        truth_v2["n_input_variants"], 0.005),
    "PtruthFallbackPm": (100 * truth_v2["conversion_class_counts"]["gene_fallback_pm"] /
                          truth_v2["n_input_variants"], 0.005),
    "PtruthCna": (100 * truth_v2["conversion_class_counts"]["amplification_cna"] /
                   truth_v2["n_input_variants"], 0.005),
    "PtruthIndel": (100 * truth_v2["conversion_class_counts"]["heuristic_indel"] /
                     truth_v2["n_input_variants"], 0.005),
    "PtruthDropped": (100 * truth_v2["conversion_class_counts"]["dropped_unmapped"] /
                       truth_v2["n_input_variants"], 0.005),
}
exp.pop("HicovRhoMag", None)
exp.pop("HicovRhoMag_unused", None)
if archive_report:
    exp["TarBytes"] = (archive_report["archive_bytes"], 0)


def norm(s):
    return float(re.sub(r"[{},%\\$]|[{}]{2,}", "", s).replace("−", "-"))


macros = {}
illegal_macro_names = []
for line in NUMBERS.read_text().splitlines():
    m = re.match(r"\\newcommand\{\\([^}]+)\}\{(.+)\}", line.strip())
    if m:
        name = m.group(1)
        if not re.fullmatch(r"[A-Za-z]+", name):
            illegal_macro_names.append(name)
        else:
            macros[name] = m.group(2).strip()

# special-case macros stored with units / signs
special = {
    "AggCoverA": norm(macros.get("AggCoverA", "0")),
    "AggAltDetA": norm(macros.get("AggAltDetA", "0")),
    "AggSpearmanMag": abs(norm(macros.get("AggSpearmanA", "0"))),
    "AggSpearmanP": norm(macros.get("AggSpearmanPA", "0")),    "HicovCover": norm(macros.get("HicovCover", "0")),
    "HicovAltDet": norm(macros.get("HicovAltDet", "0")),
    "MiniCover": norm(macros.get("MiniCover", "0")),
    "MiniAltDet": norm(macros.get("MiniAltDet", "0")),
    "DcrLeakA": norm(macros.get("DcrLeakA", "0")),
    "DcrLeakALow": norm(macros.get("DcrLeakALow", "0")),
    "DcrLeakAHigh": norm(macros.get("DcrLeakAHigh", "0")),
    "HicovRho": abs(norm(macros.get("HicovRho", "0"))),
    "HicovP": norm(macros.get("HicovP", "0")),
}

special_macro_sources = {
    "AggSpearmanMag": "AggSpearmanA",
    "AggSpearmanP": "AggSpearmanPA",
}

fails, oks, unused = [], [], []
for name in illegal_macro_names:
    fails.append(f"ILLEGAL LaTeX macro name \\{name}: command names must contain letters only")

# V2 truth-table invariants: spec_vaf is a property of emitted specifications,
# not of input rows that were classified as dropped_unmapped.
truth_class_counts = Counter(row["conversion_class"] for row in truth_rows)
if len(truth_rows) != truth_v2["n_input_variants"]:
    fails.append(
        "TRUTH ROW COUNT: "
        f"TSV={len(truth_rows)} vs summary={truth_v2['n_input_variants']}"
    )
if dict(truth_class_counts) != truth_v2["conversion_class_counts"]:
    fails.append(
        "TRUTH CLASS COUNTS: "
        f"TSV={dict(truth_class_counts)} vs summary={truth_v2['conversion_class_counts']}"
    )
dropped_with_spec_vaf = [
    row for row in truth_rows
    if row["conversion_class"] == "dropped_unmapped" and row["spec_vaf"]
]
emitted_without_spec_vaf = [
    row for row in truth_rows
    if row["conversion_class"] != "dropped_unmapped" and not row["spec_vaf"]
]
if dropped_with_spec_vaf:
    fails.append(
        f"TRUTH SEMANTICS: {len(dropped_with_spec_vaf)} dropped_unmapped rows have spec_vaf"
    )
if emitted_without_spec_vaf:
    fails.append(
        f"TRUTH SEMANTICS: {len(emitted_without_spec_vaf)} emitted rows lack spec_vaf"
    )

for name, (truth, tol) in exp.items():
    if name in special:
        got = special[name]
    elif name in macros:
        got = norm(macros[name])
    else:
        fails.append(f"MISSING macro \\{name} (expected value {truth})")
        continue
    if abs(got - truth) > tol + 1e-9:
        fails.append(f"MISMATCH \\{name}: manuscript={got} vs JSON={truth}")
    else:
        oks.append(name)

string_checks = {
    "TarMDfive": (archive_report["archive_md5"] if archive_report else
                   next(iter(manifest_tar_hashes)) if len(manifest_tar_hashes) == 1 else None),
    "TableMDfive": hashlib.md5(released17_path.read_bytes()).hexdigest(),
}
for name, truth in string_checks.items():
    got = macros.get(name)
    if truth is None:
        fails.append(f"AMBIGUOUS source for \\{name}: {sorted(manifest_tar_hashes)}")
    elif got != truth:
        fails.append(f"MISMATCH \\{name}: manuscript={got} vs manifest={truth}")
    else:
        oks.append(name)

# The p-value macro is deliberately rounded to two significant figures in scientific notation.
mini_p_match = re.fullmatch(r"\$([0-9.]+)\\times10\^\{(-?\d+)\}\$",
                            macros.get("MiniPearsonP", ""))
if not mini_p_match:
    fails.append("MALFORMED macro \\MiniPearsonP")
else:
    mini_p_got = float(mini_p_match.group(1)) * 10 ** int(mini_p_match.group(2))
    if abs(mini_p_got - mini["pearson_p"]) / mini["pearson_p"] > 0.02:
        fails.append(f"MISMATCH \\MiniPearsonP: manuscript={mini_p_got} vs JSON={mini['pearson_p']}")
    else:
        oks.append("MiniPearsonP")

checked_macro_names = (set(exp) & set(macros)) | set(special_macro_sources.values()) | set(string_checks) | {
    "MiniPearsonP"
}
defined_but_unchecked = set(macros) - checked_macro_names

print(f"Verified {len(oks)} macros against deposited JSONs and archived local evidence.")
if released17_cols != 9:
    fails.append(f"RELEASE SCHEMA: expected 9 columns, found {released17_cols}")
if defined_but_unchecked:
    print(f"Unchecked (no primary local artifact available): {sorted(defined_but_unchecked)}")
if fails:
    print("\nFAILED:")
    for f in fails:
        print("  " + f)
    sys.exit(1)
print("OK — checked manuscript macros match the archived evidence.")
