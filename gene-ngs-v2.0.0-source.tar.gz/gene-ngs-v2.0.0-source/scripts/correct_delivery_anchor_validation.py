#!/usr/bin/env python3
"""Reclassify saved delivery-depth 21-mer counts using independent hg38 contexts.

Historical counts are preserved byte for byte. This correction excludes a
reference-equals-ALT fallback from ALT evidence and restricts the correlation
to alteration-specific exact SNVs with at least two diagnostic counts.
"""

import argparse
import csv
import json
from collections import Counter
from pathlib import Path

from scipy.stats import spearmanr


ROOT = Path(__file__).resolve().parents[1]


def read(path: Path, delimiter: str) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter=delimiter))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=ROOT / "data/zenodo_staging_v2_pending")
    parser.add_argument("--workbench-figure-dir", type=Path,
                        help="Optional second output directory for manuscript plotting")
    args = parser.parse_args()
    data = args.candidate
    figures = data / "figure_data"
    counts = read(data / "delivery_anchor_counts.csv", ",")
    contexts = {(r["chrom"], r["one_based_pos"], r["alt"]): r
                for r in read(data / "hg38_independent_anchor_contexts.tsv", "\t")}
    truth = read(data / "fastq_spikein_truth.tsv", "\t")
    exact = {(r["virtual_patient_id"], r["chrom"], r["position_or_start"], r["alt_or_inserted_base"])
             for r in truth if r["conversion_class"] == "exact_snv"}
    all_exact_rows = [r for r in counts
                      if (r["patient"], r["chrom"], r["pos"], r["alt"]) in exact]
    covered = [r for r in counts if int(r["ref_count"]) + int(r["alt_count"]) > 0]
    assert len(counts) == 2241 and len(covered) == 204 and len(contexts) == 146
    qualified = []
    no_change = []
    exact_covered = []
    for row in covered:
        context = contexts[(row["chrom"], row["pos"], row["alt"])]
        if context["ref"] == row["alt"]:
            no_change.append(row)
            continue
        assert context["ref"] in "ACGT" and row["alt"] in "ACGT"
        qualified.append(row)
        if (row["patient"], row["chrom"], row["pos"], row["alt"]) in exact:
            exact_covered.append(row)
    depth2 = [r for r in exact_covered if int(r["ref_count"]) + int(r["alt_count"]) >= 2]
    rho, p = spearmanr([float(r["vaf_expected"]) for r in depth2],
                       [int(r["alt_count"]) / (int(r["ref_count"]) + int(r["alt_count"])) for r in depth2])
    result = {
        "reference_source": "UCSC hg38 initial GRCh38 primary sequence",
        "reference_accession": "GCA_000001405.15",
        "historical_fasta_byte_identity_asserted": False,
        "all_historical_anchor_rows": len(counts),
        "covered_historical_anchor_rows": len(covered),
        "covered_reference_equals_alt_fallback_rows_excluded": len(no_change),
        "historical_alt_positive_rows_from_excluded_no_change": sum(int(r["alt_count"]) > 0 for r in no_change),
        "covered_valid_reference_alt_rows": len(qualified),
        "alt_positive_valid_reference_alt_rows": sum(int(r["alt_count"]) > 0 for r in qualified),
        "all_exact_snv_anchor_rows": len(all_exact_rows),
        "covered_exact_snv_rows": len(exact_covered),
        "alt_positive_exact_snv_rows": sum(int(r["alt_count"]) > 0 for r in exact_covered),
        "depth_ge2_exact_snv_rows": len(depth2),
        "depth_ge2_exact_snv_target_observed_spearman_rho": float(rho),
        "depth_ge2_exact_snv_target_observed_spearman_p": float(p),
        "historical_counts_have_not_been_reextracted_from_reads": True,
    }
    assert (len(no_change), result["covered_valid_reference_alt_rows"], len(all_exact_rows),
            result["alt_positive_valid_reference_alt_rows"], len(exact_covered),
            result["alt_positive_exact_snv_rows"], len(depth2)) == (21, 183, 1675, 14, 138, 11, 65)
    (data / "delivery_anchor_correction.json").write_text(json.dumps(result, indent=2) + "\n")
    categories = [
        ("all anchors", len(counts)),
        ("diagnostic count >0", len(covered)),
        ("valid ref/alt count >0", len(qualified)),
        ("exact SNV count >0", len(exact_covered)),
        ("exact SNV ALT >0", result["alt_positive_exact_snv_rows"]),
    ]
    figures.mkdir(parents=True, exist_ok=True)
    targets = [figures / "fig6b_delivery_observability_corrected.tsv"]
    if args.workbench_figure_dir:
        targets.append(args.workbench_figure_dir / "fig6b_delivery_observability_corrected.tsv")
    for target in targets:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", newline="") as handle:
            writer = csv.writer(handle, delimiter="\t")
            writer.writerow(["observability_level", "count", "proportion_of_all_anchors"])
            for label, count in categories:
                writer.writerow([label, count, f"{count / len(counts):.12f}"])
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
