#!/usr/bin/env python3
"""Freeze the V2 verification scripts in the code export and data candidate."""

import gzip
import shutil
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "scripts"
EXPORT = ROOT / "github_export/gene-ngs/release_v2_verification"
OUTPUT = ROOT / "data/zenodo_staging_v2_pending/v2_verification_code.tar.gz"
SCRIPTS = (
    "audit_fastq_archive.py",
    "check_v2_release_candidate.py",
    "correct_delivery_anchor_validation.py",
    "fetch_hg38_anchor_contexts.py",
    "prepare_public_read_validation_figure_data.py",
    "verify_fastq_anchor_signatures.py",
)


def main() -> None:
    EXPORT.mkdir(parents=True, exist_ok=True)
    for name in SCRIPTS:
        shutil.copyfile(SOURCE / name, EXPORT / name)
    shutil.copyfile(ROOT / "github_export/gene-ngs/LICENSE", EXPORT / "LICENSE")
    files = [EXPORT / name for name in (*SCRIPTS, "README.md", "requirements.txt", "LICENSE")]
    with OUTPUT.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for path in sorted(files):
                    info = tarfile.TarInfo(f"v2_verification_code/{path.name}")
                    data = path.read_bytes()
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    import io
                    archive.addfile(info, io.BytesIO(data))
    print(f"Packaged {len(files)} files in {OUTPUT}")


if __name__ == "__main__":
    main()
