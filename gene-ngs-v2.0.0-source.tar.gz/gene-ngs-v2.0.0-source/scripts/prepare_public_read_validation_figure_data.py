#!/usr/bin/env python3
"""Build Figure 5 raw-read panels from the independently recounted public tar."""

import argparse
import csv
import json
from pathlib import Path

from scipy.stats import spearmanr


ROOT = Path(__file__).resolve().parents[1]


def read(path: Path, delimiter: str) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter=delimiter))


def write(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path,
                        default=ROOT / "data/zenodo_staging_v2_pending")
    parser.add_argument("--read-check-prefix", type=Path,
                        default=ROOT / "manuscript_workbench/v2/INDEPENDENT_ANCHOR_READ_CHECK")
    parser.add_argument("--workbench-figure-dir", type=Path,
                        default=ROOT / "manuscript_workbench/v2/figure_data")
    args = parser.parse_args()
    summary = json.loads(args.read_check_prefix.with_suffix(".json").read_text())
    if not (summary["valid_reference_context_rows"] == 183 and
            summary["valid_context_count_pairs_matching"] == 183 and
            summary["reference_equals_alt_rows_excluded"] == 21):
        raise ValueError("Public FASTQ anchor recount has not passed")
    detail = read(args.read_check_prefix.with_suffix(".tsv"), "\t")
    truth = read(args.candidate / "fastq_spikein_truth.tsv", "\t")
    anchors = read(args.candidate / "delivery_anchor_counts.csv", ",")
    expected_vaf = {(r["patient"], r["chrom"], r["pos"], r["alt"]): float(r["vaf_expected"])
                    for r in anchors}
    exact = {(r["virtual_patient_id"], r["chrom"], r["position_or_start"], r["alt_or_inserted_base"])
             for r in truth if r["conversion_class"] == "exact_snv"}
    pairs = []
    exact_rows = []
    for row in detail:
        if row["context_valid"] != "true":
            continue
        key = (row["virtual_patient_id"], row["chrom"], row["one_based_pos"], row["alt"])
        ref, alt = int(row["independent_ref_count"]), int(row["independent_alt_count"])
        depth = ref + alt
        pairs.append({
            "synthetic_record_id": row["synthetic_record_id"],
            "virtual_patient_id": row["virtual_patient_id"],
            "chrom": row["chrom"],
            "one_based_pos": row["one_based_pos"],
            "alt": row["alt"],
            "conversion_class": "exact_snv" if key in exact else "gene_fallback_pm",
            "historical_ref_count": row["historical_ref_count"],
            "historical_alt_count": row["historical_alt_count"],
            "independent_ref_count": ref,
            "independent_alt_count": alt,
            "historical_total": int(row["historical_ref_count"]) + int(row["historical_alt_count"]),
            "independent_total": depth,
        })
        if key in exact and depth >= 2:
            exact_rows.append({
                "synthetic_record_id": row["synthetic_record_id"],
                "virtual_patient_id": row["virtual_patient_id"],
                "chrom": row["chrom"],
                "one_based_pos": row["one_based_pos"],
                "alt": row["alt"],
                "spec_vaf": expected_vaf[key],
                "tumour_content": 0.3,
                "scaled_target_vaf": 0.3 * expected_vaf[key],
                "ref_count": ref,
                "alt_count": alt,
                "diagnostic_total": depth,
                "observed_vaf": alt / depth,
            })
    if len(pairs) != 183 or len(exact_rows) != 65:
        raise ValueError("Unexpected recount subset sizes")
    rho, p = spearmanr([r["scaled_target_vaf"] for r in exact_rows],
                       [r["observed_vaf"] for r in exact_rows])
    correction = json.loads((args.candidate / "delivery_anchor_correction.json").read_text())
    if abs(rho - correction["depth_ge2_exact_snv_target_observed_spearman_rho"]) > 1e-12:
        raise ValueError("Raw-read and saved-count Spearman statistics differ")
    for path in (args.candidate / "figure_data", args.workbench_figure_dir):
        write(path / "fig6c_independent_read_count_pairs.tsv", pairs)
        write(path / "fig6d_public_exact_snv_vaf.tsv", exact_rows)
    result = {
        "source": "independent recount of the public V1 FASTQ tar with UCSC hg38 contexts",
        "archive_md5_required": "57cbf75540c94b38c033b6e0aac70bc1",
        "valid_covered_anchor_count_pairs_matching": len(pairs),
        "reference_equals_alt_fallback_rows_excluded": 21,
        "exact_snv_depth_ge2_rows": len(exact_rows),
        "exact_snv_alt_positive_depth_ge2_rows": sum(r["alt_count"] > 0 for r in exact_rows),
        "exact_snv_scaled_target_vs_observed_spearman_rho": float(rho),
        "exact_snv_scaled_target_vs_observed_spearman_p": float(p),
        "historical_fasta_byte_identity_asserted": False,
        "claim_limit": "preselected covered anchors, not an all-variant calling benchmark",
    }
    (args.candidate / "public_read_validation_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
