#!/usr/bin/env python3
"""Prepare, but do not upload, ScienceDB V2 mapping and spike-in truth files."""

from __future__ import annotations

import argparse
import ast
import csv
import gzip
import hashlib
import json
import shutil
import tarfile
from collections import Counter
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SYN = ROOT / "data/synthetic_2017/audited_synthetic_data.csv"
DEFAULT_CONFIG = ROOT / "configs/mutation_coordinates_2017.json"
DEFAULT_SPECS = ROOT / "data/synthetic_2017/variant_specs"
DEFAULT_REANALYSIS = (
    ROOT / "data/synthetic_2017/evaluation/v2_quick_reanalysis/quick_reanalysis_results.json"
)
DEFAULT_OUT = ROOT / "data/zenodo_staging_v2_pending"


def parse_variants(value: object) -> list[dict]:
    parsed = ast.literal_eval(str(value))
    if not isinstance(parsed, list):
        raise ValueError("somatic_variants is not a list")
    return [item for item in parsed if isinstance(item, dict)]


def convert_variant(variant: dict, config: dict) -> dict:
    gene = str(variant.get("gene") or "")
    alteration = str(variant.get("alteration") or "")
    raw_vaf = variant.get("vaf")
    input_vaf = "" if raw_vaf is None or pd.isna(raw_vaf) else float(raw_vaf)
    # Preserve the simulator's executed fallback exactly: null and zero values
    # became 0.1 through ``v.get('vaf', 0.1) or 0.1`` in the orchestrator.
    emitted_vaf = float(raw_vaf or 0.1) if raw_vaf is not None and not pd.isna(raw_vaf) else 0.1
    snv = config.get("SNV", {})
    cna = config.get("CNA", {})
    key = f"{gene}:{alteration}"
    base = {
        "gene": gene,
        "alteration": alteration,
        "input_vaf": input_vaf,
        # Empty unless the row is actually written to a simulator specification.
        # In particular, dropped_unmapped rows were never passed to synggen.
        "spec_vaf": "",
        "chrom": "",
        "position_or_start": "",
        "end": "",
        "alt_or_inserted_base": "",
        "conversion_class": "dropped_unmapped",
        "spec_file": "",
        "coordinate_semantics": "not_emitted",
    }
    if key in snv:
        chrom, pos, alt_base = snv[key]
        if alt_base in {"A", "C", "G", "T"}:
            base.update(
                {
                    "chrom": chrom,
                    "position_or_start": int(pos),
                    "alt_or_inserted_base": alt_base,
                    "spec_vaf": emitted_vaf,
                    "conversion_class": "exact_snv",
                    "spec_file": "variants.pm",
                    "coordinate_semantics": "alteration-specific coordinate",
                }
            )
            return base
    if any(token in alteration for token in ["Amplification", "扩增", "拷贝数"]):
        if gene in cna:
            chrom, start, end = cna[gene]
            base.update(
                {
                    "chrom": chrom,
                    "position_or_start": int(start),
                    "end": int(end),
                    "spec_vaf": emitted_vaf,
                    "conversion_class": "amplification_cna",
                    "spec_file": "variants.cna",
                    "coordinate_semantics": "gene interval; copy number fixed to 5",
                }
            )
        return base
    if any(token in alteration for token in ["del", "dup", "ins"]):
        if gene in cna:
            chrom, start, _ = cna[gene]
            base.update(
                {
                    "chrom": chrom,
                    "position_or_start": int(start) + 500,
                    "alt_or_inserted_base": "A",
                    "spec_vaf": emitted_vaf,
                    "conversion_class": "heuristic_indel",
                    "spec_file": "variants.indel",
                    "coordinate_semantics": "gene-start heuristic, not alteration-specific",
                }
            )
        return base
    if gene in cna:
        chrom, start, _ = cna[gene]
        base.update(
            {
                "chrom": chrom,
                "position_or_start": int(start) + 100,
                "alt_or_inserted_base": "T",
                "spec_vaf": emitted_vaf,
                "conversion_class": "gene_fallback_pm",
                "spec_file": "variants.pm",
                "coordinate_semantics": "gene-start fallback, not alteration-specific",
            }
        )
    return base


def expected_spec_tuple(record: dict) -> tuple | None:
    kind = record["conversion_class"]
    if kind in {"exact_snv", "gene_fallback_pm"}:
        return (
            record["chrom"],
            int(record["position_or_start"]),
            record["alt_or_inserted_base"],
            float(record["spec_vaf"]),
            1,
            1,
        )
    if kind == "heuristic_indel":
        alteration = record["alteration"]
        return (
            record["chrom"],
            int(record["position_or_start"]),
            1 if "ins" in alteration or "dup" in alteration else 0,
            "A",
            float(record["spec_vaf"]),
            1,
            1,
        )
    if kind == "amplification_cna":
        return (
            record["chrom"],
            int(record["position_or_start"]),
            int(record["end"]),
            5,
            1,
            float(record["spec_vaf"]),
        )
    return None


def read_spec(path: Path, kind: str) -> list[tuple]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    parsed = []
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.reader(handle, delimiter="\t"):
            if kind == "pm":
                parsed.append((row[0], int(row[1]), row[2], float(row[3]), int(row[4]), int(row[5])))
            elif kind == "indel":
                parsed.append(
                    (row[0], int(row[1]), int(row[2]), row[3], float(row[4]), int(row[5]), int(row[6]))
                )
            elif kind == "cna":
                parsed.append(
                    (row[0], int(row[1]), int(row[2]), int(row[3]), int(row[4]), float(row[5]))
                )
    return parsed


def add_deterministic_specs_archive(specs_dir: Path, output: Path) -> None:
    with output.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for path in sorted(specs_dir.glob("virtual_pt_*/variants.*")):
                    info = archive.gettarinfo(str(path), arcname=str(Path("variant_specs") / path.parent.name / path.name))
                    info.uid = 0
                    info.gid = 0
                    info.uname = ""
                    info.gname = ""
                    info.mtime = 0
                    with path.open("rb") as handle:
                        archive.addfile(info, handle)


def md5(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--synthetic", type=Path, default=DEFAULT_SYN)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--specs-dir", type=Path, default=DEFAULT_SPECS)
    parser.add_argument("--reanalysis", type=Path, default=DEFAULT_REANALYSIS)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    synthetic = pd.read_csv(args.synthetic)
    sampled = synthetic.sample(n=2000, random_state=42).reset_index().rename(columns={"index": "src_row"})
    with args.config.open(encoding="utf-8") as handle:
        config = json.load(handle)

    truth_rows = []
    mapping_rows = []
    expected: dict[str, dict[str, list[tuple]]] = {}
    for patient_index, row in sampled.iterrows():
        patient = f"virtual_pt_{patient_index:04d}"
        expected[patient] = {"pm": [], "indel": [], "cna": []}
        variants = parse_variants(row["somatic_variants"])
        counts = Counter()
        for variant_index, variant in enumerate(variants):
            converted = convert_variant(variant, config)
            converted.update(
                {
                    "virtual_patient_id": patient,
                    "synthetic_csv_zero_based_row": int(row["src_row"]),
                    "simulation_seed": 42 + patient_index,
                    "input_variant_index": variant_index,
                }
            )
            truth_rows.append(converted)
            counts[converted["conversion_class"]] += 1
            spec = expected_spec_tuple(converted)
            if spec is not None:
                expected[patient][converted["spec_file"].split(".")[-1]].append(spec)
        mapping_rows.append(
            {
                "virtual_patient_id": patient,
                "fastq_filename": f"{patient}.fastq.gz",
                "synthetic_csv_zero_based_row": int(row["src_row"]),
                "synthetic_csv_one_based_data_row": int(row["src_row"]) + 1,
                "synthetic_csv_file_line_with_header": int(row["src_row"]) + 2,
                "simulation_seed": 42 + patient_index,
                "input_variant_count": len(variants),
                "exact_snv_count": counts["exact_snv"],
                "gene_fallback_pm_count": counts["gene_fallback_pm"],
                "amplification_cna_count": counts["amplification_cna"],
                "heuristic_indel_count": counts["heuristic_indel"],
                "dropped_unmapped_count": counts["dropped_unmapped"],
            }
        )

    mismatches = []
    for patient, by_kind in expected.items():
        for kind in ["pm", "indel", "cna"]:
            actual = read_spec(args.specs_dir / patient / f"variants.{kind}", kind)
            if Counter(actual) != Counter(by_kind[kind]):
                mismatches.append(
                    {
                        "patient": patient,
                        "kind": kind,
                        "expected_rows": len(by_kind[kind]),
                        "actual_rows": len(actual),
                    }
                )
    if mismatches:
        raise RuntimeError(f"Existing spec verification failed: {mismatches[:5]}")

    mapping_path = args.out_dir / "fastq_patient_mapping.csv"
    truth_path = args.out_dir / "fastq_spikein_truth.tsv"
    pd.DataFrame(mapping_rows).to_csv(mapping_path, index=False)
    pd.DataFrame(truth_rows).to_csv(truth_path, sep="\t", index=False)
    add_deterministic_specs_archive(args.specs_dir, args.out_dir / "fastq_spikein_specs.tar.gz")
    shutil.copyfile(args.reanalysis, args.out_dir / "tv_2017_v2_quick_reanalysis.json")

    summary = {
        "status": "prepared_locally_not_uploaded",
        "n_virtual_patients": len(mapping_rows),
        "n_input_variants": len(truth_rows),
        "conversion_class_counts": dict(Counter(row["conversion_class"] for row in truth_rows)),
        "spec_verification": "6000 existing per-patient spec files exactly matched reconstructed rows",
        "publication_limit": (
            "Only exact_snv rows use alteration-specific coordinates. Gene fallback PM and heuristic "
            "indel rows retain their limitations explicitly in fastq_spikein_truth.tsv."
        ),
        "vaf_semantics": (
            "input_vaf preserves the released-table value, including missing values; spec_vaf records "
            "the value actually emitted to a simulator specification and is empty for dropped_unmapped "
            "rows. For emitted rows, the executed orchestrator used 0.1 when the input VAF was missing "
            "or zero."
        ),
    }
    with (args.out_dir / "fastq_truth_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
        handle.write("\n")

    manifest_lines = []
    for path in sorted(args.out_dir.rglob("*")):
        if path.is_file() and path.name != "MANIFEST_V2_PENDING.md5":
            manifest_lines.append(f"{md5(path)}  {path.relative_to(args.out_dir).as_posix()}")
    (args.out_dir / "MANIFEST_V2_PENDING.md5").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
