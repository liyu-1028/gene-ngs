#!/usr/bin/env python3
"""Build V2 record indexes and explicit truth qualification flags.

The inputs are the byte-frozen public V1 cohort and locally reconstructed V2
mapping/truth. FASTQ observations are populated only from a completed archive
audit; absent evidence remains blank and marked pending.
"""

import argparse
import csv
import hashlib
import re
from collections import defaultdict
from pathlib import Path


def rows(path: Path, delimiter: str = ",") -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter=delimiter))


def write_rows(path: Path, fieldnames: list[str], values: list[dict[str, str]], delimiter: str = "\t") -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=delimiter)
        writer.writeheader()
        writer.writerows(values)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def md5(path: Path) -> str:
    digest = hashlib.md5()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", type=Path, default=Path("data/zenodo_staging/synthetic_msk_impact_2017_cohort.csv"))
    parser.add_argument("--mapping", type=Path, default=Path("data/zenodo_staging_v2_pending/fastq_patient_mapping.csv"))
    parser.add_argument("--truth", type=Path, default=Path("data/zenodo_staging_v2_pending/fastq_spikein_truth.tsv"))
    parser.add_argument("--fastq-audit", type=Path, help="Completed per-member TSV from audit_fastq_archive.py")
    parser.add_argument("--simulation-log", type=Path, default=Path("data/synthetic_2017/simulation.log"))
    parser.add_argument("--fallback-contexts", type=Path,
                        default=Path("data/zenodo_staging_v2_pending/hg38_fallback_contexts.tsv"))
    parser.add_argument("--out-dir", type=Path, default=Path("data/zenodo_staging_v2_pending"))
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    cohort = rows(args.cohort)
    mapping = rows(args.mapping)
    truth = rows(args.truth, "\t")
    fallback_contexts = {(item["chrom"], item["one_based_pos"], item["alt"]): item
                         for item in rows(args.fallback_contexts, "\t")}
    if len(fallback_contexts) != 378:
        raise ValueError("The independent hg38 fallback-context audit is incomplete")
    if len(cohort) != 10328 or len(mapping) != 2000 or len(truth) != 26790:
        raise ValueError("Unexpected source row counts; review source identity before continuing")
    if len({row["synthetic_csv_zero_based_row"] for row in mapping}) != len(mapping):
        raise ValueError("Duplicate mapped CSV row")
    if len({row["fastq_filename"] for row in mapping}) != len(mapping):
        raise ValueError("Duplicate mapped FASTQ filename")

    cohort_hash = sha256(args.cohort)
    by_row = {int(row["synthetic_csv_zero_based_row"]): row for row in mapping}
    index_rows = []
    for index in range(len(cohort)):
        mapped = by_row.get(index)
        index_rows.append({
            "synthetic_record_id": f"SYN2017_{index:05d}",
            "synthetic_csv_filename": args.cohort.name,
            "synthetic_csv_sha256": cohort_hash,
            "synthetic_csv_zero_based_row": str(index),
            "synthetic_csv_one_based_data_row": str(index + 1),
            "has_fastq": "true" if mapped else "false",
            "virtual_patient_id": mapped["virtual_patient_id"] if mapped else "",
        })
    write_rows(args.out_dir / "sample_index.tsv", list(index_rows[0]), index_rows)

    audited = {}
    if args.fastq_audit:
        audit_rows = rows(args.fastq_audit, "\t")
        audited = {row["name"]: row for row in audit_rows}
        if len(audited) != 2000 or any(row["error"] for row in audit_rows):
            raise ValueError("FASTQ audit is incomplete or reports errors")
    enhanced_mapping = []
    for item in mapping:
        row = dict(item)
        filename = row["fastq_filename"]
        audit = audited.get(filename)
        row.update({
            "synthetic_record_id": f"SYN2017_{int(row['synthetic_csv_zero_based_row']):05d}",
            "archive_member_path": filename,
            "fastq_md5": audit["md5"] if audit else "",
            "fastq_compressed_bytes": audit["compressed_bytes"] if audit else "",
            "read_count": audit["reads"] if audit else "",
            "read_length_bp": "100" if audit else "",
            "fastq_audit_status": "verified" if audit else "pending_full_archive_audit",
        })
        enhanced_mapping.append(row)
    write_rows(args.out_dir / "fastq_patient_mapping_v2.csv", list(enhanced_mapping[0]), enhanced_mapping, ",")

    loci = defaultdict(list)
    for row in truth:
        if row["spec_file"] == "variants.pm":
            loci[(row["virtual_patient_id"], row["chrom"], row["position_or_start"])].append(row)
    conflicting = {}
    duplicate = {}
    for key, group in sorted(loci.items()):
        if len(group) <= 1:
            continue
        values = {(row["alt_or_inserted_base"], row["spec_vaf"]) for row in group}
        if len(values) > 1:
            conflicting[key] = f"AMB_PM_{len(conflicting)+1:04d}"
        else:
            duplicate[key] = f"DUP_PM_{len(duplicate)+1:04d}"
    indels = defaultdict(list)
    for row in truth:
        if row["conversion_class"] == "heuristic_indel":
            indels[row["virtual_patient_id"]].append(row)
    error_count = defaultdict(int)
    active_patient = None
    ansi = re.compile(r"\x1b\[[0-9;]*m")
    for raw_line in args.simulation_log.read_text(errors="replace").splitlines():
        line = ansi.sub("", raw_line)
        started = re.search(r"Simulating (virtual_pt_\d{4}) with seed", line)
        if started:
            active_patient = started.group(1)
        error = re.search(r"ERROR: at line (\d+) the specified small deletion is not compatible", line)
        if error:
            if active_patient is None:
                raise ValueError("Simulation error appears before patient identifier")
            error_count[(active_patient, int(error.group(1)))] += 1
    error_rows = []
    error_variants = {}
    for (patient, spec_line), count in sorted(error_count.items()):
        candidates = indels[patient]
        candidate = candidates[spec_line - 1] if 0 < spec_line <= len(candidates) else None
        variant_id = (f"{patient}_v{int(candidate['input_variant_index']):03d}" if candidate else "")
        if variant_id:
            error_variants[variant_id] = count
        error_rows.append({
            "virtual_patient_id": patient,
            "spec_file": "variants.indel",
            "one_based_spec_line": str(spec_line),
            "log_occurrences": str(count),
            "candidate_variant_id": variant_id,
            "mapping_basis": "one-based variants.indel line inferred from simulator log",
            "message": "specified small deletion is not compatible with the reference genome",
            "status": "reported_in_simulator_log; member FASTQ may still exist",
        })
    write_rows(args.out_dir / "simulator_error_flags.tsv", list(error_rows[0]), error_rows)
    flags = []
    no_change_patients = set()
    no_change_loci = set()
    no_change_rows = 0
    for row in truth:
        key = (row["virtual_patient_id"], row["chrom"], row["position_or_start"])
        kind = row["conversion_class"]
        variant_id = f"{row['virtual_patient_id']}_v{int(row['input_variant_index']):03d}"
        context = fallback_contexts.get((row["chrom"], row["position_or_start"],
                                         row["alt_or_inserted_base"])) if kind == "gene_fallback_pm" else None
        if kind == "gene_fallback_pm" and context is None:
            raise ValueError(f"Missing fallback reference context: {variant_id}")
        no_change = context is not None and context["ref"] == row["alt_or_inserted_base"]
        if no_change:
            no_change_rows += 1
            no_change_patients.add(row["virtual_patient_id"])
            no_change_loci.add((row["chrom"], row["position_or_start"], row["alt_or_inserted_base"]))
        if kind == "dropped_unmapped":
            status = "not_emitted"
        elif variant_id in error_variants:
            status = "simulator_reported_reference_incompatibility"
        elif no_change:
            status = "reference_equals_alt_on_independent_hg38"
        elif key in conflicting and row["spec_file"] == "variants.pm":
            status = "excluded_ambiguous_same_locus"
        elif key in duplicate and row["spec_file"] == "variants.pm":
            status = "excluded_duplicate_same_locus"
        elif kind == "exact_snv":
            status = "pending_reference_and_read_validation"
        else:
            status = "not_exact_snv_benchmark"
        flags.append({
            "variant_id": variant_id,
            "virtual_patient_id": row["virtual_patient_id"],
            "input_variant_index": row["input_variant_index"],
            "conversion_class": kind,
            "emitted_to_spec": "false" if kind == "dropped_unmapped" else "true",
            "same_locus_group_id": conflicting.get(key, duplicate.get(key, "")) if row["spec_file"] == "variants.pm" else "",
            "benchmark_validation_status": status,
            "reference_allele": context["ref"] if context else "",
            "reference_source": context["reference_source"] if context else "",
            "read_observation_status": "not_tested",
            "simulator_error_occurrences": str(error_variants.get(variant_id, 0)),
        })
    if len({row["variant_id"] for row in flags}) != len(flags):
        raise ValueError("Variant IDs are not unique")
    write_rows(args.out_dir / "variant_quality_flags.tsv", list(flags[0]), flags)
    if (len(no_change_loci), no_change_rows, len(no_change_patients)) != (97, 1074, 731):
        raise ValueError("Unexpected hg38 fallback no-change counts")

    manifest_path = args.out_dir / "MANIFEST_V2_PENDING.md5"
    manifest_lines = []
    for path in sorted(args.out_dir.rglob("*")):
        if path.is_file() and path != manifest_path:
            manifest_lines.append(f"{md5(path)}  {path.relative_to(args.out_dir).as_posix()}")
    manifest_path.write_text("\n".join(manifest_lines) + "\n")
    print({"sample_index_rows": len(index_rows), "fastq_mapping_rows": len(enhanced_mapping),
           "truth_flag_rows": len(flags), "ambiguous_pm_groups": len(conflicting),
           "same_spec_duplicate_groups": len(duplicate), "simulator_error_occurrences": sum(error_count.values()),
           "affected_indel_spec_lines": len(error_rows), "fastq_audited": len(audited),
           "fallback_reference_equals_alt_loci": len(no_change_loci),
           "fallback_reference_equals_alt_rows": no_change_rows,
           "fallback_reference_equals_alt_patients": len(no_change_patients)})


if __name__ == "__main__":
    main()
