#!/usr/bin/env python3
"""Prepare deterministic, figure-ready data for manuscript Figures 3--6.

The script reads only the publishable 2017-derived workflow.  It does not read
the private 50K cohort, retrain CTGAN, regenerate FASTQ, or render final figures.
It validates derived values against the archived JSON results before writing.
"""

from __future__ import annotations

import argparse
import ast
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors

from reanalyse_2017_quick import parse_variants, privacy_feature_matrices


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REAL = ROOT / "data/real/msk_impact_2017/real_dataset.csv"
DEFAULT_SYNTHETIC = ROOT / "data/synthetic_2017/audited_synthetic_data.csv"
DEFAULT_STATISTICAL = ROOT / "data/zenodo_staging/tv_2017_statistical_fidelity.json"
DEFAULT_QUICK = (
    ROOT
    / "data/synthetic_2017/evaluation/v2_quick_reanalysis/quick_reanalysis_results.json"
)
DEFAULT_TRUTH_SUMMARY = ROOT / "data/zenodo_staging_v2_pending/fastq_truth_summary.json"
DEFAULT_DELIVERY = ROOT / "data/synthetic_2017/evaluation/aggregate_anchor_detail.csv"
DEFAULT_DELIVERY_SUMMARY = (
    ROOT / "data/synthetic_2017/evaluation/aggregate_anchor_detail_summary.json"
)
DEFAULT_MINISIM = (
    ROOT
    / "data/synthetic_2017/evaluation/v2_quick_reanalysis/minisim_anchor_provenance.tsv"
)
DEFAULT_OUTPUT = ROOT / "manuscript_workbench/v2/figure_data"
DEFAULT_V2 = ROOT / "data/zenodo_staging_v2_pending"


def read_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def assert_close(observed: float, expected: float, label: str, atol: float = 5e-5) -> None:
    if not math.isclose(float(observed), float(expected), rel_tol=0, abs_tol=atol):
        raise ValueError(f"{label}: observed {observed!r}, expected {expected!r}")


def prepare_frames(real_path: Path, synthetic_path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    real = pd.read_csv(real_path)
    synthetic = pd.read_csv(synthetic_path)
    for frame in (real, synthetic):
        frame["_variants"] = frame["somatic_variants"].map(parse_variants)
        frame["_gene_set"] = frame["_variants"].map(
            lambda variants: {str(item.get("gene")) for item in variants if item.get("gene")}
        )
    return real, synthetic


def write_tsv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, sep="\t", index=False, float_format="%.12g")


def figure3(
    real: pd.DataFrame,
    synthetic: pd.DataFrame,
    statistical: dict,
    output: Path,
) -> dict:
    ecdf_parts = []
    for label, frame in (("Real", real), ("Synthetic", synthetic)):
        values = np.sort(pd.to_numeric(frame["biomarkers.tmb"], errors="coerce").dropna())
        ecdf_parts.append(
            pd.DataFrame(
                {
                    "dataset": label,
                    "tmb": values,
                    "ecdf": np.arange(1, len(values) + 1) / len(values),
                }
            )
        )
    ecdf = pd.concat(ecdf_parts, ignore_index=True)
    write_tsv(ecdf, output / "fig3a_tmb_ecdf.tsv")

    gender_rows = []
    translation = {"女": "Female", "男": "Male"}
    for label, frame in (("Real", real), ("Synthetic", synthetic)):
        counts = frame["patient_info.gender"].fillna("Missing").astype(str).value_counts()
        for source_value, count in counts.items():
            gender_rows.append(
                {
                    "dataset": label,
                    "source_value": source_value,
                    "display_label": translation.get(source_value, source_value),
                    "count": int(count),
                    "proportion": count / len(frame),
                }
            )
    gender = pd.DataFrame(gender_rows)
    write_tsv(gender, output / "fig3b_gender_composition.tsv")

    real_counts = Counter(gene for genes in real["_gene_set"] for gene in genes)
    synthetic_counts = Counter(gene for genes in synthetic["_gene_set"] for gene in genes)
    top30 = [gene for gene, _ in real_counts.most_common(30)]
    genes = pd.DataFrame(
        [
            {
                "rank_by_real_frequency": rank,
                "gene": gene,
                "real_frequency": real_counts[gene] / len(real),
                "synthetic_frequency": synthetic_counts[gene] / len(synthetic),
                "absolute_difference": abs(
                    real_counts[gene] / len(real) - synthetic_counts[gene] / len(synthetic)
                ),
            }
            for rank, gene in enumerate(top30, start=1)
        ]
    )
    write_tsv(genes, output / "fig3cd_top30_gene_frequencies.tsv")

    archived = statistical["Somatic_Variant_Fidelity"]
    assert_close(
        genes["absolute_difference"].mean(),
        archived["Average_Gene_Frequency_Difference"],
        "Fig. 3 mean absolute top-30 gene-frequency difference",
    )
    tp53 = genes.loc[genes["gene"] == "TP53"].iloc[0]
    archived_tp53 = archived["Top_Gene_Differences"]["TP53"]
    assert_close(tp53["real_frequency"], archived_tp53["Real_Frequency"], "Fig. 3 TP53 real")
    assert_close(
        tp53["synthetic_frequency"], archived_tp53["Synthetic_Frequency"], "Fig. 3 TP53 synthetic"
    )
    return {
        "tmb_rows": len(ecdf),
        "gender_rows": len(gender),
        "gene_rows": len(genes),
        "ks_tmb": statistical["Univariate_Marginal_Similarity"]["biomarkers.tmb"]["KS_statistic"],
        "gender_tvd": statistical["Univariate_Marginal_Similarity"]["patient_info.gender"]["TVD"],
        "top30_mean_absolute_difference": float(genes["absolute_difference"].mean()),
    }


def figure4(quick: dict, output: Path) -> dict:
    c04 = quick["C04_tstr"]
    per_seed = pd.DataFrame(c04["per_seed"])
    per_seed["auroc_gap_trtr_minus_tstr"] = per_seed["trtr_auroc"] - per_seed["tstr_auroc"]
    per_seed["f1_gap_trtr_minus_tstr"] = per_seed["trtr_f1"] - per_seed["tstr_f1"]
    per_seed["top10_genes_selected_from_real_training_fold"] = per_seed[
        "top10_genes_selected_from_real_training_fold"
    ].map(lambda values: "|".join(values))
    write_tsv(per_seed, output / "fig4abc_tstr_per_seed.tsv")

    summary_rows = []
    for key, metric, model in (
        ("trtr_auroc", "AUROC", "TRTR"),
        ("tstr_auroc", "AUROC", "TSTR"),
        ("trtr_f1", "F1", "TRTR"),
        ("tstr_f1", "F1", "TSTR"),
    ):
        item = c04[key]
        summary_rows.append(
            {
                "metric": metric,
                "model": model,
                "mean": item["mean"],
                "empirical_interval_low": item["empirical_95pct_interval"][0],
                "empirical_interval_high": item["empirical_95pct_interval"][1],
            }
        )
    summary = pd.DataFrame(summary_rows)
    write_tsv(summary, output / "fig4d_tstr_summary.tsv")
    prevalence = pd.DataFrame(
        [
            {"dataset": "Real", "positive_rate_tmb_ge_10": c04["real_positive_rate"]},
            {"dataset": "Synthetic", "positive_rate_tmb_ge_10": c04["synthetic_positive_rate"]},
        ]
    )
    write_tsv(prevalence, output / "fig4d_task_prevalence.tsv")
    return {"per_seed_rows": len(per_seed), "summary_rows": len(summary)}


def dcr_per_record(real: pd.DataFrame, synthetic: pd.DataFrame) -> tuple[pd.DataFrame, float]:
    x_real, x_synthetic, _ = privacy_feature_matrices(real, synthetic)
    unique_real, inverse = np.unique(x_real, axis=0, return_inverse=True)
    nearest = NearestNeighbors(n_neighbors=2, algorithm="brute", n_jobs=-1).fit(unique_real)
    real_distances, _ = nearest.kneighbors(unique_real)
    threshold = float(np.percentile(real_distances[:, 1][inverse], 5))
    cross_distances, _ = nearest.kneighbors(x_synthetic)
    dcr = cross_distances[:, 0]
    second = cross_distances[:, 1]
    nndr = np.divide(dcr, second, out=np.full_like(dcr, np.nan), where=second > 0)
    frame = pd.DataFrame(
        {
            "synthetic_csv_zero_based_row": np.arange(len(synthetic), dtype=int),
            "nearest_distinct_real_distance": dcr,
            "second_nearest_distinct_real_distance": second,
            "nndr": nndr,
            "exact_zero_distance": np.isclose(dcr, 0.0, atol=1e-12),
            "below_positive_real_fifth_percentile": dcr < threshold,
        }
    )
    return frame, threshold


def figure5(
    real: pd.DataFrame,
    synthetic: pd.DataFrame,
    quick: dict,
    output: Path,
    v2_dir: Path | None,
) -> dict:
    c01 = quick["C01_dcr_nndr"]
    c02 = quick["C02_exact_match"]
    c03 = quick["C03_discriminator"]

    match_rows = []
    for key, label in (
        ("shared_clinical_only", "Seven shared clinical fields"),
        ("complete_variant_list_only", "Complete order-invariant variant list"),
        (
            "shared_clinical_plus_complete_variant_list",
            "Shared clinical fields plus complete variant list",
        ),
    ):
        item = c02[key]
        match_rows.append(
            {
                "definition": label,
                "matched_synthetic_rows": item["matched_synthetic_rows"],
                "matched_unique_patterns": item["matched_unique_patterns"],
                "synthetic_row_rate": item["synthetic_row_rate"],
            }
        )
    write_tsv(pd.DataFrame(match_rows), output / "fig5a_exact_match_definitions.tsv")

    distances, threshold = dcr_per_record(real, synthetic)
    write_tsv(distances, output / "fig5b_dcr_nndr_per_record.tsv")
    if v2_dir is not None:
        write_tsv(distances, v2_dir / "tv_2017_dcr_nndr_per_record.tsv")
    archived_distance = c01["synthetic_to_distinct_real_dcr"]
    assert_close(threshold, c01["positive_distinct_real_to_real_dcr"]["fifth_percentile_threshold"], "Fig. 5 threshold", 1e-10)
    assert_close(distances["nearest_distinct_real_distance"].median(), archived_distance["median"], "Fig. 5 DCR median", 1e-10)
    assert_close(distances["nndr"].median(), c01["synthetic_nndr"]["median"], "Fig. 5 NNDR median", 1e-10)
    if int(distances["exact_zero_distance"].sum()) != archived_distance["exact_zero_count"]:
        raise ValueError("Fig. 5 exact-zero DCR count does not match archived JSON")
    if int(distances["below_positive_real_fifth_percentile"].sum()) != archived_distance[
        "below_positive_real_fifth_percentile_count"
    ]:
        raise ValueError("Fig. 5 below-threshold count does not match archived JSON")

    discriminator = pd.DataFrame(c03["per_seed"])
    write_tsv(discriminator, output / "fig5cd_discriminator_per_seed.tsv")
    discriminator_summary = pd.DataFrame(
        [
            {
                "metric": key,
                "mean": c03[key]["mean"],
                "empirical_interval_low": c03[key]["empirical_95pct_interval"][0],
                "empirical_interval_high": c03[key]["empirical_95pct_interval"][1],
            }
            for key in ("accuracy", "f1", "auroc")
        ]
    )
    write_tsv(discriminator_summary, output / "fig5cd_discriminator_summary.tsv")
    return {
        "exact_match_definitions": len(match_rows),
        "distance_rows": len(distances),
        "dcr_threshold": threshold,
        "discriminator_rows": len(discriminator),
    }


def figure6(
    truth_summary: dict,
    delivery_path: Path,
    delivery_summary: dict,
    minisim_path: Path,
    quick: dict,
    output: Path,
    v2_dir: Path | None,
) -> dict:
    total = truth_summary["n_input_variants"]
    truth = pd.DataFrame(
        [
            {"conversion_class": key, "count": count, "proportion": count / total}
            for key, count in truth_summary["conversion_class_counts"].items()
        ]
    )
    write_tsv(truth, output / "fig6a_truth_conversion_classes.tsv")

    delivery = pd.read_csv(delivery_path)
    delivery["depth"] = delivery["ref_count"] + delivery["alt_count"]
    observed_counts = {
        "all anchors": int(len(delivery)),
        "locus covered": int((delivery["depth"] > 0).sum()),
        "ALT detected": int((delivery["alt_count"] > 0).sum()),
        "depth at least 2": int((delivery["depth"] >= 2).sum()),
    }
    delivery_rows = pd.DataFrame(
        [
            {
                "observability_level": label,
                "count": count,
                "proportion_of_all_anchors": count / len(delivery),
            }
            for label, count in observed_counts.items()
        ]
    )
    write_tsv(delivery_rows, output / "fig6b_delivery_observability.tsv")
    if len(delivery) != delivery_summary["anchors"]:
        raise ValueError("Fig. 6 delivery anchor count does not match summary")
    assert_close(
        observed_counts["locus covered"] / len(delivery),
        delivery_summary["locus_cover_rate"],
        "Fig. 6 delivery locus coverage",
        5e-4,
    )
    assert_close(
        observed_counts["ALT detected"] / len(delivery),
        delivery_summary["alt_detectability"],
        "Fig. 6 delivery ALT detectability",
        5e-4,
    )
    if observed_counts["depth at least 2"] != delivery_summary["anchors_with_ge2_reads"]:
        raise ValueError("Fig. 6 depth>=2 count does not match summary")

    minisim = pd.read_csv(minisim_path, sep="\t")
    exact = minisim[
        (minisim["provenance"] == "exact_snv")
        & (~minisim["ambiguous_duplicate_locus"].map(lambda value: bool(value)))
    ].copy()
    exact["observed_minus_target_vaf"] = exact["obs_vaf"] - exact["tc_vaf"]
    exact["plot_status"] = np.where(exact["detected"], "ALT detected", "ALT not detected")
    write_tsv(exact, output / "fig6cd_exact_snv_minisim.tsv")
    if v2_dir is not None:
        write_tsv(minisim, v2_dir / "minisim_anchor_provenance.tsv")
    archived = quick["C05_minisim"]["primary_exact_snv_loci"]
    with (output / "fig6_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "delivery_depth": {
                    "vaf_spearman_rho": delivery_summary["vaf_spearman_rho"],
                    "vaf_p": delivery_summary["vaf_p"],
                },
                "primary_exact_snv_loci": archived,
            },
            handle,
            indent=2,
        )
        handle.write("\n")
    if len(exact) != archived["n_rows"]:
        raise ValueError("Fig. 6 exact-SNV row count does not match archived JSON")
    if int(exact["detected"].sum()) != archived["n_alt_detected"]:
        raise ValueError("Fig. 6 exact-SNV ALT-detected count does not match archived JSON")
    assert_close(exact["observed_minus_target_vaf"].mean(), archived["mean_signed_observed_minus_target"], "Fig. 6 signed bias", 1e-10)
    return {
        "truth_rows": len(truth),
        "delivery_anchor_rows": len(delivery),
        "exact_snv_rows": len(exact),
        "exact_snv_alt_detected": int(exact["detected"].sum()),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--real", type=Path, default=DEFAULT_REAL)
    parser.add_argument("--synthetic", type=Path, default=DEFAULT_SYNTHETIC)
    parser.add_argument("--statistical", type=Path, default=DEFAULT_STATISTICAL)
    parser.add_argument("--quick", type=Path, default=DEFAULT_QUICK)
    parser.add_argument("--truth-summary", type=Path, default=DEFAULT_TRUTH_SUMMARY)
    parser.add_argument("--delivery", type=Path, default=DEFAULT_DELIVERY)
    parser.add_argument("--delivery-summary", type=Path, default=DEFAULT_DELIVERY_SUMMARY)
    parser.add_argument("--minisim", type=Path, default=DEFAULT_MINISIM)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--write-v2",
        action="store_true",
        help="Also write the two missing public derived tables into the local V2 staging directory.",
    )
    parser.add_argument("--v2-dir", type=Path, default=DEFAULT_V2)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    real, synthetic = prepare_frames(args.real, args.synthetic)
    statistical = read_json(args.statistical)
    quick = read_json(args.quick)
    truth_summary = read_json(args.truth_summary)
    delivery_summary = read_json(args.delivery_summary)
    v2_dir = args.v2_dir if args.write_v2 else None
    if v2_dir is not None:
        v2_dir.mkdir(parents=True, exist_ok=True)

    checks = {
        "scope": "2017-derived publishable cohort only; private 50K files were not read",
        "figure_3": figure3(real, synthetic, statistical, args.output),
        "figure_4": figure4(quick, args.output),
        "figure_5": figure5(real, synthetic, quick, args.output, v2_dir),
        "figure_6": figure6(
            truth_summary,
            args.delivery,
            delivery_summary,
            args.minisim,
            quick,
            args.output,
            v2_dir,
        ),
    }
    with (args.output / "STAGE5_DATA_CHECKS.json").open("w", encoding="utf-8") as handle:
        json.dump(checks, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    print(args.output / "STAGE5_DATA_CHECKS.json")


if __name__ == "__main__":
    main()
