#!/usr/bin/env python3
"""Bounded V2 reanalysis for the publishable 2017-derived cohort.

This script implements the 40-minute version of review items C01--C05.  It does
not retrain CTGAN, regenerate FASTQ files, or read the private 50K cohort.
Outputs are deterministic for the software versions recorded in the result.
"""

from __future__ import annotations

import argparse
import ast
import json
import math
import platform
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import sklearn
from scipy.stats import pearsonr, spearmanr
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import OneHotEncoder, StandardScaler


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REAL = ROOT / "data/real/msk_impact_2017/real_dataset.csv"
DEFAULT_SYN = ROOT / "data/synthetic_2017/audited_synthetic_data.csv"
DEFAULT_MINISIM = ROOT / "data/synthetic_2017/evaluation/hicov_minisim/per_anchor.tsv"
DEFAULT_CONFIG = ROOT / "configs/mutation_coordinates_2017.json"
DEFAULT_OUT = ROOT / "data/synthetic_2017/evaluation/v2_quick_reanalysis"

SHARED_CLINICAL_COLUMNS = [
    "patient_info.age",
    "patient_info.gender",
    "patient_info.pathological_diagnosis",
    "patient_info.sample_type",
    "biomarkers.tmb",
    "biomarkers.msi",
    "qc_metrics.overall_quality",
]


def parse_variants(value: object) -> list[dict]:
    if isinstance(value, list):
        parsed = value
    elif pd.isna(value) or not str(value).strip():
        parsed = []
    else:
        parsed = ast.literal_eval(str(value))
    if not isinstance(parsed, list):
        raise ValueError("somatic_variants is not a list")
    return [item for item in parsed if isinstance(item, dict)]


def norm_scalar(value: object) -> str:
    if pd.isna(value):
        return "<NA>"
    if isinstance(value, (float, np.floating)):
        return format(float(value), ".12g")
    return str(value).strip()


def canonical_variants(variants: list[dict]) -> tuple[tuple[str, str, str], ...]:
    rows = []
    for variant in variants:
        rows.append(
            (
                norm_scalar(variant.get("gene")),
                norm_scalar(variant.get("alteration")),
                norm_scalar(variant.get("vaf")),
            )
        )
    return tuple(sorted(rows))


def canonical_record(row: pd.Series, columns: list[str], include_variants: bool) -> tuple:
    values: list[object] = [norm_scalar(row.get(column)) for column in columns]
    if include_variants:
        values.append(canonical_variants(row["_variants"]))
    return tuple(values)


def percentile_summary(values: list[float]) -> dict:
    arr = np.asarray(values, dtype=float)
    return {
        "mean": float(np.mean(arr)),
        "median": float(np.median(arr)),
        "empirical_95pct_interval": [
            float(np.percentile(arr, 2.5)),
            float(np.percentile(arr, 97.5)),
        ],
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
    }


def round_floats(value: object, digits: int = 12) -> object:
    """Remove non-semantic last-bit differences from parallel numeric libraries."""
    if isinstance(value, dict):
        return {key: round_floats(item, digits) for key, item in value.items()}
    if isinstance(value, list):
        return [round_floats(item, digits) for item in value]
    if isinstance(value, (float, np.floating)) and math.isfinite(float(value)):
        return round(float(value), digits)
    return value


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> list[float]:
    if total == 0:
        return [math.nan, math.nan]
    p = successes / total
    denom = 1 + z * z / total
    centre = (p + z * z / (2 * total)) / denom
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denom
    return [centre - half, centre + half]


def exact_match_reanalysis(real: pd.DataFrame, syn: pd.DataFrame) -> dict:
    real_shared = [canonical_record(row, SHARED_CLINICAL_COLUMNS, False) for _, row in real.iterrows()]
    syn_shared = [canonical_record(row, SHARED_CLINICAL_COLUMNS, False) for _, row in syn.iterrows()]
    real_full = [canonical_record(row, SHARED_CLINICAL_COLUMNS, True) for _, row in real.iterrows()]
    syn_full = [canonical_record(row, SHARED_CLINICAL_COLUMNS, True) for _, row in syn.iterrows()]
    real_variants = [canonical_variants(value) for value in real["_variants"]]
    syn_variants = [canonical_variants(value) for value in syn["_variants"]]

    def compare(reference: list[tuple], candidate: list[tuple]) -> dict:
        reference_set = set(reference)
        matched_rows = sum(item in reference_set for item in candidate)
        return {
            "matched_synthetic_rows": int(matched_rows),
            "matched_unique_patterns": int(len(reference_set & set(candidate))),
            "synthetic_row_rate": float(matched_rows / len(candidate)),
        }

    release_columns = [column for column in syn.columns if not column.startswith("_")][:9]
    release_scalar_columns = [column for column in release_columns if column != "somatic_variants"]
    synthetic_nine = [
        canonical_record(row, release_scalar_columns, True)
        for _, row in syn.iterrows()
    ]
    return {
        "definition_note": (
            "The released synthetic table has nine columns, but audit_stage has no real-table "
            "counterpart. Cross-set comparisons therefore use the seven shared semantic clinical "
            "columns, with the complete order-invariant variant list added for the full-record test."
        ),
        "shared_clinical_columns": SHARED_CLINICAL_COLUMNS,
        "shared_clinical_only": compare(real_shared, syn_shared),
        "complete_variant_list_only": compare(real_variants, syn_variants),
        "shared_clinical_plus_complete_variant_list": compare(real_full, syn_full),
        "synthetic_nine_column_internal_duplicates_beyond_first": int(
            len(synthetic_nine) - len(set(synthetic_nine))
        ),
    }


def mutation_features(frame: pd.DataFrame, genes: list[str]) -> pd.DataFrame:
    result = pd.DataFrame(index=frame.index)
    result["biomarkers.tmb"] = pd.to_numeric(frame["biomarkers.tmb"], errors="coerce")
    result["patient_info.gender"] = frame["patient_info.gender"].fillna("Missing").astype(str)
    for gene in genes:
        result[f"Mut_{gene}"] = frame["_gene_set"].map(lambda values, g=gene: int(g in values))
    return result


def privacy_feature_matrices(real: pd.DataFrame, syn: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, list[str]]:
    gene_counts = Counter(gene for genes in real["_gene_set"] for gene in genes)
    top10 = [gene for gene, _ in gene_counts.most_common(10)]
    columns = ["biomarkers.tmb", "patient_info.gender"] + [f"Mut_{gene}" for gene in top10]
    real_features = mutation_features(real, top10)
    syn_features = mutation_features(syn, top10)
    median_tmb = float(real_features["biomarkers.tmb"].median())
    real_features["biomarkers.tmb"] = real_features["biomarkers.tmb"].fillna(median_tmb)
    syn_features["biomarkers.tmb"] = syn_features["biomarkers.tmb"].fillna(median_tmb)
    transformer = ColumnTransformer(
        [
            ("numeric", StandardScaler(), ["biomarkers.tmb"]),
            (
                "categorical",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                ["patient_info.gender"],
            ),
            ("binary", "passthrough", [f"Mut_{gene}" for gene in top10]),
        ]
    )
    x_real = transformer.fit_transform(real_features[columns])
    x_syn = transformer.transform(syn_features[columns])
    return np.asarray(x_real, dtype=float), np.asarray(x_syn, dtype=float), columns


def dcr_nndr_reanalysis(x_real: np.ndarray, x_syn: np.ndarray, columns: list[str]) -> dict:
    unique_real, inverse, counts = np.unique(x_real, axis=0, return_inverse=True, return_counts=True)
    if len(unique_real) < 2:
        raise ValueError("DCR/NNDR requires at least two distinct real feature vectors")

    distinct_nn = NearestNeighbors(n_neighbors=2, algorithm="brute", n_jobs=-1).fit(unique_real)
    distinct_distances, _ = distinct_nn.kneighbors(unique_real)
    distinct_intra = distinct_distances[:, 1]
    weighted_intra = distinct_intra[inverse]
    threshold = float(np.percentile(weighted_intra, 5))

    cross_distances, _ = distinct_nn.kneighbors(x_syn)
    d1 = cross_distances[:, 0]
    d2 = cross_distances[:, 1]
    nndr = np.divide(d1, d2, out=np.full_like(d1, np.nan), where=d2 > 0)
    below = int(np.sum(d1 < threshold))
    exact_zero = int(np.sum(np.isclose(d1, 0.0, atol=1e-12)))

    return {
        "feature_definition": columns,
        "distance": "Euclidean after real-only TMB standardization, gender one-hot encoding, and top-10 gene indicators",
        "n_real_rows": int(len(x_real)),
        "n_distinct_real_feature_vectors": int(len(unique_real)),
        "real_duplicate_feature_vector_rows_beyond_first": int(len(x_real) - len(unique_real)),
        "positive_distinct_real_to_real_dcr": {
            "median": float(np.median(weighted_intra)),
            "fifth_percentile_threshold": threshold,
        },
        "synthetic_to_distinct_real_dcr": {
            "median": float(np.median(d1)),
            "fifth_percentile": float(np.percentile(d1, 5)),
            "minimum": float(np.min(d1)),
            "exact_zero_count": exact_zero,
            "exact_zero_rate": float(exact_zero / len(d1)),
            "below_positive_real_fifth_percentile_count": below,
            "below_positive_real_fifth_percentile_rate": float(below / len(d1)),
            "wilson_95pct_interval": wilson_interval(below, len(d1)),
        },
        "synthetic_nndr": {
            "definition": "nearest-distinct-real distance divided by second-nearest-distinct-real distance",
            "median": float(np.nanmedian(nndr)),
            "fifth_percentile": float(np.nanpercentile(nndr, 5)),
            "ninety_fifth_percentile": float(np.nanpercentile(nndr, 95)),
        },
        "interpretation_limit": "This is a relative distance diagnostic, not a formal privacy guarantee.",
    }


def discriminator_reanalysis(x_real: np.ndarray, x_syn: np.ndarray, repeats: int) -> dict:
    sample_size = min(len(x_real), len(x_syn))
    rows = []
    for seed in range(repeats):
        rng = np.random.default_rng(seed)
        real_idx = rng.choice(len(x_real), sample_size, replace=False)
        syn_idx = rng.choice(len(x_syn), sample_size, replace=False)
        x = np.vstack([x_real[real_idx], x_syn[syn_idx]])
        y = np.concatenate([np.ones(sample_size, dtype=int), np.zeros(sample_size, dtype=int)])
        x_train, x_test, y_train, y_test = train_test_split(
            x, y, test_size=0.5, random_state=seed, stratify=y
        )
        model = RandomForestClassifier(
            n_estimators=100, max_depth=5, random_state=seed, n_jobs=-1
        ).fit(x_train, y_train)
        probability = model.predict_proba(x_test)[:, 1]
        prediction = (probability >= 0.5).astype(int)
        rows.append(
            {
                "seed": seed,
                "accuracy": float(np.mean(prediction == y_test)),
                "f1": float(f1_score(y_test, prediction)),
                "auroc": float(roc_auc_score(y_test, probability)),
            }
        )
    return {
        "name": "real_vs_synthetic_discriminator",
        "repeats": repeats,
        "accuracy": percentile_summary([row["accuracy"] for row in rows]),
        "f1": percentile_summary([row["f1"] for row in rows]),
        "auroc": percentile_summary([row["auroc"] for row in rows]),
        "per_seed": rows,
        "membership_inference_status": "not_estimable_from_current_artifacts",
        "reason": (
            "The generator was trained on the full 2017 table and no pre-training real non-member "
            "holdout was preserved. Real-versus-synthetic classification measures fidelity, not membership inference."
        ),
    }


def make_tstr_features(frame: pd.DataFrame, genes: list[str]) -> pd.DataFrame:
    features = pd.DataFrame(index=frame.index)
    features["patient_info.gender"] = frame["patient_info.gender"].fillna("Missing").astype(str)
    for gene in genes:
        features[f"Mut_{gene}"] = frame["_gene_set"].map(lambda values, g=gene: int(g in values))
    return features


def tstr_reanalysis(real: pd.DataFrame, syn: pd.DataFrame, repeats: int) -> dict:
    y_real = (pd.to_numeric(real["biomarkers.tmb"], errors="coerce").fillna(0) >= 10).astype(int)
    y_syn = (pd.to_numeric(syn["biomarkers.tmb"], errors="coerce").fillna(0) >= 10).astype(int)
    rows = []
    for seed in range(repeats):
        train_idx, test_idx = train_test_split(
            np.arange(len(real)), test_size=0.3, random_state=seed, stratify=y_real
        )
        gene_counts = Counter(gene for genes in real.iloc[train_idx]["_gene_set"] for gene in genes)
        top10 = [gene for gene, _ in gene_counts.most_common(10)]
        feature_columns = ["patient_info.gender"] + [f"Mut_{gene}" for gene in top10]
        x_real = make_tstr_features(real, top10)
        x_syn = make_tstr_features(syn, top10)

        def preprocessor() -> ColumnTransformer:
            return ColumnTransformer(
                [
                    (
                        "categorical",
                        OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                        ["patient_info.gender"],
                    ),
                    ("binary", "passthrough", [f"Mut_{gene}" for gene in top10]),
                ]
            )

        pre_trtr = preprocessor()
        x_real_train = pre_trtr.fit_transform(x_real.iloc[train_idx][feature_columns])
        x_real_test_trtr = pre_trtr.transform(x_real.iloc[test_idx][feature_columns])
        trtr = RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=-1).fit(
            x_real_train, y_real.iloc[train_idx]
        )

        pre_tstr = preprocessor()
        x_syn_train = pre_tstr.fit_transform(x_syn[feature_columns])
        x_real_test_tstr = pre_tstr.transform(x_real.iloc[test_idx][feature_columns])
        tstr = RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=-1).fit(
            x_syn_train, y_syn
        )
        p_trtr = trtr.predict_proba(x_real_test_trtr)[:, 1]
        p_tstr = tstr.predict_proba(x_real_test_tstr)[:, 1]
        pred_trtr = (p_trtr >= 0.5).astype(int)
        pred_tstr = (p_tstr >= 0.5).astype(int)
        rows.append(
            {
                "seed": seed,
                "top10_genes_selected_from_real_training_fold": top10,
                "trtr_auroc": float(roc_auc_score(y_real.iloc[test_idx], p_trtr)),
                "tstr_auroc": float(roc_auc_score(y_real.iloc[test_idx], p_tstr)),
                "trtr_f1": float(f1_score(y_real.iloc[test_idx], pred_trtr, zero_division=0)),
                "tstr_f1": float(f1_score(y_real.iloc[test_idx], pred_tstr, zero_division=0)),
            }
        )
    return {
        "task": "Predict TMB >= 10",
        "protocol": (
            "Repeated 70/30 stratified real-data splits. Top-10 genes are selected from each real "
            "training fold only. TRTR and TSTR preprocessors are fitted only on their respective training data."
        ),
        "repeats": repeats,
        "real_positive_rate": float(y_real.mean()),
        "synthetic_positive_rate": float(y_syn.mean()),
        "trtr_auroc": percentile_summary([row["trtr_auroc"] for row in rows]),
        "tstr_auroc": percentile_summary([row["tstr_auroc"] for row in rows]),
        "trtr_f1": percentile_summary([row["trtr_f1"] for row in rows]),
        "tstr_f1": percentile_summary([row["tstr_f1"] for row in rows]),
        "per_seed": rows,
    }


def classify_pm_provenance(syn: pd.DataFrame, config: dict) -> dict[str, list[tuple]]:
    sampled = syn.drop(columns=["_variants", "_gene_set"]).sample(n=2000, random_state=42).reset_index()
    snv = config.get("SNV", {})
    cna = config.get("CNA", {})
    result: dict[str, list[tuple]] = {}
    for patient_index, row in sampled.iterrows():
        patient = f"virtual_pt_{patient_index:04d}"
        converted = []
        for variant in parse_variants(row["somatic_variants"]):
            gene = str(variant.get("gene") or "")
            alteration = str(variant.get("alteration") or "")
            vaf = float(variant.get("vaf", 0.1) or 0.1)
            key = f"{gene}:{alteration}"
            if key in snv and str(snv[key][2]) in {"A", "C", "G", "T"}:
                chrom, pos, alt = snv[key]
                converted.append((chrom, int(pos), alt, round(vaf, 4), "exact_snv", gene, alteration))
            elif not any(token in alteration for token in ["Amplification", "扩增", "拷贝数"]):
                if not any(token in alteration for token in ["del", "dup", "ins"]) and gene in cna:
                    chrom, start, _ = cna[gene]
                    converted.append(
                        (chrom, int(start) + 100, "T", round(vaf, 4), "fallback_pm", gene, alteration)
                    )
        result[patient] = converted
    return result


def regression_metrics(frame: pd.DataFrame) -> dict:
    used = frame[frame["obs_vaf"].notna()].copy()
    x = used["tc_vaf"].to_numpy(dtype=float)
    y = used["obs_vaf"].to_numpy(dtype=float)
    slope, intercept = np.polyfit(x, y, 1)
    pearson = pearsonr(x, y)
    spearman = spearmanr(x, y)
    return {
        "n_rows": int(len(frame)),
        "n_with_depth": int(len(used)),
        "n_alt_detected": int(used["detected"].astype(bool).sum()),
        "pearson_r": float(pearson.statistic),
        "spearman_rho": float(spearman.statistic),
        "slope": float(slope),
        "intercept": float(intercept),
        "mean_signed_observed_minus_target": float(np.mean(y - x)),
        "mean_absolute_error": float(np.mean(np.abs(y - x))),
        "root_mean_squared_error": float(np.sqrt(np.mean((y - x) ** 2))),
    }


def bootstrap_slope_bias(frame: pd.DataFrame, repeats: int = 2000) -> dict:
    used = frame[frame["obs_vaf"].notna()].copy()
    x = used["tc_vaf"].to_numpy(dtype=float)
    y = used["obs_vaf"].to_numpy(dtype=float)
    rng = np.random.default_rng(42)
    slopes = []
    biases = []
    for _ in range(repeats):
        idx = rng.integers(0, len(x), len(x))
        if np.ptp(x[idx]) == 0:
            continue
        slopes.append(float(np.polyfit(x[idx], y[idx], 1)[0]))
        biases.append(float(np.mean(y[idx] - x[idx])))
    return {
        "bootstrap_repeats": len(slopes),
        "slope_95pct_interval": [float(np.percentile(slopes, 2.5)), float(np.percentile(slopes, 97.5))],
        "mean_signed_bias_95pct_interval": [
            float(np.percentile(biases, 2.5)),
            float(np.percentile(biases, 97.5)),
        ],
    }


def minisim_reanalysis(syn: pd.DataFrame, minisim_path: Path, config: dict, out_dir: Path) -> dict:
    anchors = pd.read_csv(minisim_path, sep="\t")
    provenance = classify_pm_provenance(syn, config)
    labels = []
    source_variants = []
    for _, row in anchors.iterrows():
        candidates = [
            item
            for item in provenance.get(row["patient"], [])
            if item[0] == row["chrom"]
            and item[1] == int(row["pos"])
            and item[2] == row["alt"]
            and abs(item[3] - float(row["spec_vaf"])) < 1e-6
        ]
        labels.append("|".join(sorted({item[4] for item in candidates})) or "unknown")
        source_variants.append("|".join(f"{item[5]}:{item[6]}" for item in candidates))
    anchors["provenance"] = labels
    anchors["source_variant"] = source_variants
    locus = ["patient", "chrom", "pos", "alt"]
    anchors["ambiguous_duplicate_locus"] = anchors.duplicated(locus, keep=False)
    anchors.to_csv(out_dir / "minisim_anchor_provenance.tsv", sep="\t", index=False)

    unambiguous = anchors[~anchors["ambiguous_duplicate_locus"]]
    exact = unambiguous[unambiguous["provenance"] == "exact_snv"]
    primary = regression_metrics(exact)
    primary.update(bootstrap_slope_bias(exact))
    return {
        "provenance_counts": {key: int(value) for key, value in anchors["provenance"].value_counts().items()},
        "ambiguous_duplicate_locus_rows": int(anchors["ambiguous_duplicate_locus"].sum()),
        "n_unique_patient_loci": int(anchors[locus].drop_duplicates().shape[0]),
        "all_reported_rows": regression_metrics(anchors),
        "unambiguous_loci": regression_metrics(unambiguous),
        "primary_exact_snv_loci": primary,
        "primary_interpretation": (
            "Exact-SNV anchors show association between target and observed VAF, but the slope and "
            "signed bias indicate systematic under-recovery. Fallback PM, indel and CNA behavior is not validated here."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--real", type=Path, default=DEFAULT_REAL)
    parser.add_argument("--synthetic", type=Path, default=DEFAULT_SYN)
    parser.add_argument("--minisim", type=Path, default=DEFAULT_MINISIM)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--repeats", type=int, default=10)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    real = pd.read_csv(args.real)
    syn = pd.read_csv(args.synthetic)
    for frame in (real, syn):
        frame["_variants"] = frame["somatic_variants"].map(parse_variants)
        frame["_gene_set"] = frame["_variants"].map(
            lambda variants: {str(item.get("gene")) for item in variants if item.get("gene")}
        )
    with args.config.open(encoding="utf-8") as handle:
        config = json.load(handle)

    x_real, x_syn, privacy_columns = privacy_feature_matrices(real, syn)
    results = {
        "scope": "2017-derived publishable cohort only; private 50K files were not read",
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
        },
        "inputs": {
            "real": str(args.real.relative_to(ROOT)),
            "synthetic": str(args.synthetic.relative_to(ROOT)),
            "minisim": str(args.minisim.relative_to(ROOT)),
            "coordinate_config": str(args.config.relative_to(ROOT)),
        },
        "C01_dcr_nndr": dcr_nndr_reanalysis(x_real, x_syn, privacy_columns),
        "C02_exact_match": exact_match_reanalysis(real, syn),
        "C03_discriminator": discriminator_reanalysis(x_real, x_syn, args.repeats),
        "C04_tstr": tstr_reanalysis(real, syn, args.repeats),
        "C05_minisim": minisim_reanalysis(syn, args.minisim, config, args.out_dir),
    }
    results = round_floats(results)
    output = args.out_dir / "quick_reanalysis_results.json"
    with output.open("w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    print(output)


if __name__ == "__main__":
    main()
