#!/usr/bin/env python3
"""Render the merged workflow/linkage figure as editable SVG and PNG."""

from html import escape
from pathlib import Path

import fitz


OUT = Path(__file__).resolve().parents[1] / "paper"
BLUE, ORANGE, GREEN, PURPLE, GREY = "#0072B2", "#D55E00", "#009E73", "#9A4E8B", "#596579"


def node(x, y, w, h, lines, color, dashed=False, font=17):
    dash = ' stroke-dasharray="6 5"' if dashed else ""
    center = y + h / 2 - (len(lines) - 1) * 11
    txt = "".join(f'<text x="{x+w/2}" y="{center+22*i}" text-anchor="middle" font-size="{font}">{escape(line)}</text>' for i, line in enumerate(lines))
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="9" fill="white" stroke="{color}" stroke-width="2"{dash}/>{txt}'


def arrow(x1, y1, x2, y2):
    return f'<path d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{GREY}" stroke-width="2" marker-end="url(#arrow)"/>'


def note(y, words, font=16):
    return f'<text x="500" y="{y}" text-anchor="middle" font-size="{font}" fill="{GREY}">{escape(words)}</text>'


def panel(y, h, letter, title):
    return (f'<rect x="10" y="{y}" width="980" height="{h}" rx="12" fill="white" stroke="#D1D5DB"/>'
            f'<text x="28" y="{y+34}" font-size="24" font-weight="bold">{letter}</text>'
            f'<text x="68" y="{y+33}" font-size="21" font-weight="bold">{escape(title)}</text>'
            f'<path d="M28 {y+47} H972" stroke="#D1D5DB"/>')


def main():
    svg = "\n".join([
        '<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="850" viewBox="0 0 1000 850">',
        '<defs><marker id="arrow" markerWidth="10" markerHeight="8" refX="9" refY="4" orient="auto"><path d="M0 0 L10 4 L0 8 Z" fill="#596579"/></marker></defs>',
        '<style>text{font-family:Arial,Helvetica,sans-serif;fill:#1F2937;dominant-baseline:middle}</style>',
        '<rect width="1000" height="850" fill="white"/>',
        panel(10, 260, "a", "Generation and computational screening"),
        node(28,92,183,88,["MSK-IMPACT 2017","10,945 records"],BLUE),
        node(269,92,214,88,["CTGAN clinical fields","+ recombined","variant lists"],ORANGE,font=16),
        node(540,92,186,88,["10,945 candidates","all pass hard rules"],PURPLE),
        node(784,92,188,88,["10,328 released","synthetic rows"],GREEN),
        arrow(211,136,269,136),arrow(483,136,540,136),arrow(726,136,784,136),
        note(211,"2,000 candidates received an additional LLM-assisted screen:"),
        note(239,"1,383 retained; 608 content exclusions; 9 API-error exclusions"),
        panel(290,235,"b","Released objects and the locally prepared link"),
        node(28,372,244,85,["Public V1","10,328-row CSV"],BLUE),
        node(375,372,244,85,["Local V2 candidate","row index + file mapping","input truth + quality flags","simulator specs"],PURPLE,True,13),
        node(722,372,250,85,["Public V1","2,000 single-end FASTQ"],BLUE),
        arrow(272,414,375,414),arrow(619,414,722,414),
        note(495,"Stable row ID and archive member MD5 make each sampled CSV-to-FASTQ link auditable.",15),
        panel(545,295,"c","Example row mapping and truth semantics"),
        node(28,635,235,83,["SYN2017_04139","CSV row 4139 (zero based)","data row 4140 (one based)"],BLUE,font=14),
        node(365,635,230,83,["virtual_pt_0000","seed 42"],GREEN),
        node(696,635,276,83,["virtual_pt_0000.fastq.gz","200,000 single-end","100-bp reads"],BLUE,font=15),
        arrow(263,676,365,676),arrow(595,676,696,676),
        note(760,"exact_snv: alteration-specific coordinate; fallback/heuristic: surrogate specification",15),
        note(792,"dropped_unmapped: not emitted. Classification does not establish read-level detection.",15),
        '</svg>',
    ]).encode("utf-8")
    (OUT / "fig1_generation_and_linkage.svg").write_bytes(svg)
    doc = fitz.open(stream=svg, filetype="svg")
    doc[0].get_pixmap(matrix=fitz.Matrix(4.25,4.25),alpha=False).save(OUT / "fig1_generation_and_linkage.png")


if __name__ == "__main__":
    main()
