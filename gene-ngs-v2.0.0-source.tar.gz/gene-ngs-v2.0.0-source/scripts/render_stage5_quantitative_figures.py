#!/usr/bin/env python3
"""Render four quantitative panels from frozen TSV data.

The generated ``fig3``--``fig6`` filenames are historical workbench names; the
manuscript places them as Figures 2--5. The default outputs are review previews.
For the manuscript, use ``--final-names --dpi 600`` and copy the four output
PNGs to the corresponding ``paper/fig2``--``paper/fig5`` filenames.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA = ROOT / "manuscript_workbench/v2/figure_data"
DEFAULT_OUTPUT = ROOT / "manuscript_workbench/v2/figure_previews"

REAL = "#0072B2"
SYNTHETIC = "#D55E00"
GREEN = "#009E73"
PURPLE = "#CC79A7"
GREY = "#6B7280"
DARK = "#374151"
LIGHT = "#D1D5DB"


def configure() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 8,
            "axes.labelsize": 9,
            "axes.titlesize": 9,
            "legend.fontsize": 7.5,
            "xtick.labelsize": 7.5,
            "ytick.labelsize": 7.5,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.linewidth": 0.7,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
        }
    )


def read_tsv(data_dir: Path, name: str) -> pd.DataFrame:
    return pd.read_csv(data_dir / name, sep="\t")


def read_json(data_dir: Path, name: str) -> dict:
    with (data_dir / name).open(encoding="utf-8") as handle:
        return json.load(handle)


def panel(ax: plt.Axes, label: str) -> None:
    ax.text(-0.12, 1.06, label, transform=ax.transAxes, fontsize=12, fontweight="bold", va="top")


def style_axis(ax: plt.Axes) -> None:
    ax.grid(axis="y", color=LIGHT, linewidth=0.5, alpha=0.55)
    ax.set_axisbelow(True)


def save(fig: plt.Figure, output: Path, stem: str, dpi: int, png_only: bool = False) -> None:
    output.mkdir(parents=True, exist_ok=True)
    fig.savefig(output / f"{stem}.png", dpi=dpi, bbox_inches="tight")
    if not png_only:
        fig.savefig(output / f"{stem}.pdf", bbox_inches="tight")
    plt.close(fig)


def render_figure3(data_dir: Path, output: Path, dpi: int, final_names: bool) -> None:
    ecdf = read_tsv(data_dir, "fig3a_tmb_ecdf.tsv")
    gender = read_tsv(data_dir, "fig3b_gender_composition.tsv")
    genes = read_tsv(data_dir, "fig3cd_top30_gene_frequencies.tsv")
    fig, axes = plt.subplots(2, 2, figsize=(7.09, 6.40), constrained_layout=True)
    ax = axes[0, 0]
    ecdf_styles = (("Real", REAL, "-"), ("Synthetic", SYNTHETIC, "--"))
    for name, color, line in ecdf_styles:
        part = ecdf[ecdf["dataset"] == name]
        ax.step(part["tmb"], part["ecdf"], where="post", color=color, linestyle=line, label=name, linewidth=1.6)
    ax.set(xlabel="TMB (mutations per Mb)", ylabel="Empirical cumulative proportion")
    ax.legend(
        frameon=False,
        loc="lower right",
        bbox_to_anchor=(1.0, 1.01),
        ncol=2,
        borderaxespad=0,
        columnspacing=1.2,
        handlelength=2.4,
    )
    style_axis(ax)

    # The full TMB range is dominated by a long right tail, so the visually
    # compressed low-TMB bend is repeated in an inset.  The arrow identifies
    # the empirical-CDF separation that defines the reported KS statistic.
    inset = ax.inset_axes([0.40, 0.20, 0.56, 0.62])
    for name, color, line in ecdf_styles:
        part = ecdf[ecdf["dataset"] == name]
        inset.step(part["tmb"], part["ecdf"], where="post", color=color, linestyle=line, linewidth=1.15)
    inset.set(xlim=(0, 15), ylim=(0.20, 0.92), xlabel="TMB", ylabel="ECDF")
    inset.set_title("Low-TMB detail", loc="left", fontsize=7, pad=2)
    inset.tick_params(axis="both", labelsize=6, length=2, pad=1.5)
    inset.xaxis.label.set_size(6.5)
    inset.yaxis.label.set_size(6.5)
    inset.xaxis.labelpad = 1
    inset.yaxis.labelpad = 1
    inset.grid(axis="both", color=LIGHT, linewidth=0.4, alpha=0.5)
    inset.set_axisbelow(True)

    real_tmb = np.sort(ecdf.loc[ecdf["dataset"] == "Real", "tmb"].to_numpy())
    synthetic_tmb = np.sort(ecdf.loc[ecdf["dataset"] == "Synthetic", "tmb"].to_numpy())
    combined_tmb = np.unique(np.concatenate((real_tmb, synthetic_tmb)))
    real_cdf = np.searchsorted(real_tmb, combined_tmb, side="right") / real_tmb.size
    synthetic_cdf = np.searchsorted(synthetic_tmb, combined_tmb, side="right") / synthetic_tmb.size
    ks_index = int(np.argmax(np.abs(real_cdf - synthetic_cdf)))
    ks_x = combined_tmb[ks_index]
    ks_low = min(real_cdf[ks_index], synthetic_cdf[ks_index])
    ks_high = max(real_cdf[ks_index], synthetic_cdf[ks_index])
    ks_value = ks_high - ks_low
    inset.annotate(
        "",
        xy=(ks_x, ks_high),
        xytext=(ks_x, ks_low),
        arrowprops={"arrowstyle": "<->", "color": DARK, "lw": 0.8},
    )
    inset.text(
        0.97,
        0.06,
        f"KS = {ks_value:.4f}",
        transform=inset.transAxes,
        ha="right",
        va="bottom",
        fontsize=6.5,
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.9, "pad": 1.2},
    )
    ax.add_patch(
        Rectangle(
            (0, 0.20),
            15,
            0.72,
            fill=False,
            edgecolor=GREY,
            linewidth=0.8,
            linestyle=":",
            zorder=2,
        )
    )
    panel(ax, "a")

    ax = axes[0, 1]
    labels = ["Female", "Male"]
    x = np.arange(len(labels))
    width = 0.34
    for offset, name, color, hatch in ((-width / 2, "Real", REAL, ""), (width / 2, "Synthetic", SYNTHETIC, "//")):
        part = gender[gender["dataset"] == name].set_index("display_label").reindex(labels)
        bars = ax.bar(x + offset, part["proportion"], width, color=color, hatch=hatch, label=name)
        for bar, value in zip(bars, part["proportion"]):
            ax.text(bar.get_x() + bar.get_width() / 2, value + 0.012, f"{value:.1%}", ha="center", va="bottom", fontsize=7)
    ax.set_xticks(x, labels)
    ax.set(ylabel="Proportion of records", ylim=(0, 0.7))
    gender_props = gender.pivot(index="display_label", columns="dataset", values="proportion")
    gender_tvd = (gender_props["Real"] - gender_props["Synthetic"]).abs().sum() / 2
    ax.text(
        0.97,
        0.92,
        f"TVD = {gender_tvd:.4f}",
        transform=ax.transAxes,
        ha="right",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.9, "pad": 1.5},
    )
    ax.legend(
        frameon=False,
        loc="lower right",
        bbox_to_anchor=(1.0, 1.01),
        ncol=2,
        borderaxespad=0,
        columnspacing=1.2,
        handlelength=2.4,
    )
    style_axis(ax)
    panel(ax, "b")

    ax = axes[1, 0]
    colors = np.where(genes["gene"] == "TP53", PURPLE, DARK)
    ax.scatter(genes["real_frequency"], genes["synthetic_frequency"], c=colors, s=28, alpha=0.9)
    limit = max(genes["real_frequency"].max(), genes["synthetic_frequency"].max()) * 1.08
    ax.plot([0, limit], [0, limit], color=GREY, linestyle=":", linewidth=1.2, label="identity")
    tp53 = genes[genes["gene"] == "TP53"].iloc[0]
    ax.annotate(
        f"TP53\n({tp53['real_frequency']:.4f}, {tp53['synthetic_frequency']:.4f})",
        (tp53["real_frequency"], tp53["synthetic_frequency"]),
        xytext=(-64, -12), textcoords="offset points",
        arrowprops={"arrowstyle": "-", "color": PURPLE, "lw": 0.8}, color=PURPLE,
    )
    ax.set(xlabel="Real frequency", ylabel="Synthetic frequency", xlim=(0, limit), ylim=(0, limit))
    ax.set_aspect("equal", adjustable="box")
    ax.legend(frameon=False, loc="lower right")
    style_axis(ax)
    panel(ax, "c")

    ax = axes[1, 1]
    ordered = genes.sort_values("absolute_difference", ascending=True)
    y = np.arange(len(ordered))
    for yi, value, gene in zip(y, ordered["absolute_difference"], ordered["gene"]):
        color = PURPLE if gene == "TP53" else DARK
        ax.hlines(yi, 0, value, color=color, linewidth=0.8)
        ax.plot(value, yi, "o", color=color, markersize=3.2)
    mean_difference = genes["absolute_difference"].mean()
    ax.axvline(mean_difference, color=GREY, linestyle="--", linewidth=1, label=f"mean = {mean_difference:.4f}")
    ax.set_yticks(y, ordered["gene"], fontsize=5.8)
    ax.set(xlabel="Absolute frequency difference", ylabel="Gene")
    ax.legend(frameon=False, loc="lower right")
    ax.grid(axis="x", color=LIGHT, linewidth=0.5, alpha=0.55)
    panel(ax, "d")
    suffix = "" if final_names else "_preview"
    save(fig, output, f"fig3_statistical_fidelity{suffix}", dpi, png_only=final_names)


def render_figure4(data_dir: Path, output: Path, dpi: int, final_names: bool) -> None:
    per_seed = read_tsv(data_dir, "fig4abc_tstr_per_seed.tsv")
    prevalence = read_tsv(data_dir, "fig4d_task_prevalence.tsv")
    summary = read_tsv(data_dir, "fig4d_tstr_summary.tsv")
    fig, axes = plt.subplots(2, 2, figsize=(7.09, 5.91), constrained_layout=True)
    seeds = per_seed["seed"]
    ax = axes[0, 0]
    for _, row in per_seed.iterrows():
        ax.plot([row["seed"] - 0.08, row["seed"] + 0.08], [row["trtr_auroc"], row["tstr_auroc"]], color=LIGHT, linewidth=0.7)
    ax.scatter(seeds - 0.08, per_seed["trtr_auroc"], color=REAL, marker="o", label="TRTR")
    ax.scatter(seeds + 0.08, per_seed["tstr_auroc"], facecolors="none", edgecolors=SYNTHETIC, marker="^", label="TSTR")
    ax.axhline(0.5, color=GREY, linestyle=":", linewidth=1, label="chance reference")
    ax.set(xlabel="Split seed", ylabel="AUROC", ylim=(0.35, 0.85), xticks=seeds)
    ax.legend(frameon=False, ncol=3, loc="lower left")
    style_axis(ax)
    panel(ax, "a")

    ax = axes[0, 1]
    for _, row in per_seed.iterrows():
        ax.plot([row["seed"] - 0.08, row["seed"] + 0.08], [row["trtr_f1"], row["tstr_f1"]], color=LIGHT, linewidth=0.7)
    ax.scatter(seeds - 0.08, per_seed["trtr_f1"], color=REAL, marker="o", label="TRTR")
    ax.scatter(seeds + 0.08, per_seed["tstr_f1"], facecolors="none", edgecolors=SYNTHETIC, marker="^", label="TSTR")
    ax.set(xlabel="Split seed", ylabel="F1 score", ylim=(0, 0.5), xticks=seeds)
    ax.legend(frameon=False)
    style_axis(ax)
    panel(ax, "b")

    ax = axes[1, 0]
    ax.scatter(seeds - 0.08, per_seed["auroc_gap_trtr_minus_tstr"], color=REAL, marker="o", label="AUROC gap")
    ax.scatter(seeds + 0.08, per_seed["f1_gap_trtr_minus_tstr"], color=SYNTHETIC, marker="^", label="F1 gap")
    ax.axhline(0, color=GREY, linestyle=":", linewidth=1)
    ax.axhline(per_seed["auroc_gap_trtr_minus_tstr"].mean(), color=REAL, linewidth=0.9, alpha=0.7)
    ax.axhline(per_seed["f1_gap_trtr_minus_tstr"].mean(), color=SYNTHETIC, linewidth=0.9, alpha=0.7)
    ax.set(xlabel="Split seed", ylabel="TRTR − TSTR", ylim=(-0.02, 0.44), xticks=seeds)
    ax.legend(frameon=False)
    style_axis(ax)
    panel(ax, "c")

    container = axes[1, 1]
    container.axis("off")
    left = container.inset_axes([0.0, 0.08, 0.30, 0.84])
    right = container.inset_axes([0.62, 0.08, 0.38, 0.84])
    prevalence_x = np.arange(len(prevalence))
    bars = left.bar(prevalence_x, prevalence["positive_rate_tmb_ge_10"], color=[REAL, SYNTHETIC], width=0.62)
    for bar, value in zip(bars, prevalence["positive_rate_tmb_ge_10"]):
        left.text(bar.get_x() + bar.get_width() / 2, value + 0.003, f"{value:.2%}", ha="center", fontsize=7)
    left.set_xticks(prevalence_x, prevalence["dataset"])
    left.set(ylabel="TMB≥10 positive rate", ylim=(0, 0.15))
    left.tick_params(axis="x", rotation=20)
    style_axis(left)
    labels = [f"{r.metric} {r.model}" for r in summary.itertuples()]
    y = np.arange(len(summary))[::-1]
    colors = [REAL if model == "TRTR" else SYNTHETIC for model in summary["model"]]
    for yi, (_, row), color in zip(y, summary.iterrows(), colors):
        right.errorbar(row["mean"], yi, xerr=[[row["mean"] - row["empirical_interval_low"]], [row["empirical_interval_high"] - row["mean"]]], fmt="o", color=color, capsize=2)
    right.set_yticks(y, labels)
    right.tick_params(axis="y", labelsize=6.5)
    right.set(xlabel="Mean and empirical interval", xlim=(0, 0.9))
    right.grid(axis="x", color=LIGHT, linewidth=0.5, alpha=0.55)
    panel(container, "d")
    suffix = "" if final_names else "_preview"
    save(fig, output, f"fig4_tstr_utility{suffix}", dpi, png_only=final_names)


def render_figure5(data_dir: Path, output: Path, dpi: int, final_names: bool) -> None:
    matches = read_tsv(data_dir, "fig5a_exact_match_definitions.tsv")
    distances = read_tsv(data_dir, "fig5b_dcr_nndr_per_record.tsv")
    discriminator = read_tsv(data_dir, "fig5cd_discriminator_per_seed.tsv")
    summary = read_tsv(data_dir, "fig5cd_discriminator_summary.tsv").set_index("metric")
    checks = read_json(data_dir, "STAGE5_DATA_CHECKS.json")
    fig, axes = plt.subplots(2, 2, figsize=(7.09, 5.91), constrained_layout=True)
    ax = axes[0, 0]
    labels = ["Clinical fields", "Variant list", "Combined full record"]
    y = np.arange(3)
    bars = ax.barh(y, matches["matched_synthetic_rows"], color=[REAL, SYNTHETIC, PURPLE])
    ax.set_xscale("log")
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlabel("Matched synthetic rows (log scale)")
    for bar, count, rate in zip(bars, matches["matched_synthetic_rows"], matches["synthetic_row_rate"]):
        rate_label = f"{rate:.5%}" if rate < 0.001 else f"{rate:.3%}"
        ax.text(count * 1.12, bar.get_y() + bar.get_height() / 2, f"{count} ({rate_label})", va="center", fontsize=7)
    ax.grid(axis="x", color=LIGHT, linewidth=0.5, alpha=0.55)
    panel(ax, "a")

    container = axes[0, 1]
    container.axis("off")
    upper = container.inset_axes([0.12, 0.62, 0.86, 0.32])
    lower = container.inset_axes([0.12, 0.06, 0.86, 0.34])
    dcr = np.sort(distances["nearest_distinct_real_distance"].to_numpy())
    ecdf = np.arange(1, len(dcr) + 1) / len(dcr)
    upper.plot(dcr, ecdf, color=PURPLE, linewidth=1.4)
    threshold = checks["figure_5"]["dcr_threshold"]
    upper.axvline(threshold, color=GREY, linestyle=":", linewidth=1, label=f"real reference {threshold:.6f}")
    upper.axvline(np.median(dcr), color=DARK, linestyle="--", linewidth=1, label=f"median {np.median(dcr):.5f}")
    upper.set(
        xlabel="DCR (display truncated at 99th percentile)",
        ylabel="ECDF",
        xlim=(0, np.percentile(dcr, 99)),
    )
    upper.legend(frameon=False, loc="lower right", fontsize=6.5)
    nndr = np.sort(distances["nndr"].dropna().to_numpy())
    lower.plot(nndr, np.arange(1, len(nndr) + 1) / len(nndr), color=GREEN, linewidth=1.4)
    lower.axvline(np.median(nndr), color=DARK, linestyle="--", linewidth=1, label=f"median {np.median(nndr):.4f}")
    lower.set(xlabel="NNDR", ylabel="ECDF", xlim=(0, 1))
    lower.legend(frameon=False, loc="lower right", fontsize=6.5)
    panel(container, "b")

    ax = axes[1, 0]
    seeds = discriminator["seed"]
    ax.scatter(seeds - 0.08, discriminator["accuracy"], color=REAL, marker="o", label="Accuracy")
    ax.scatter(seeds + 0.08, discriminator["f1"], facecolors="none", edgecolors=SYNTHETIC, marker="^", label="F1")
    ax.axhline(summary.loc["accuracy", "mean"], color=REAL, linewidth=0.9)
    ax.axhline(summary.loc["f1", "mean"], color=SYNTHETIC, linewidth=0.9)
    ax.axhline(0.5, color=GREY, linestyle=":", linewidth=1, label="accuracy reference")
    ax.set(xlabel="Repetition seed", ylabel="Score", ylim=(0.48, 0.73), xticks=seeds)
    ax.legend(frameon=False, ncol=2)
    style_axis(ax)
    panel(ax, "c")

    ax = axes[1, 1]
    ax.scatter(seeds, discriminator["auroc"], color=PURPLE, marker="o")
    mean = summary.loc["auroc", "mean"]
    low = summary.loc["auroc", "empirical_interval_low"]
    high = summary.loc["auroc", "empirical_interval_high"]
    ax.axhspan(low, high, color=PURPLE, alpha=0.14, label=f"empirical interval {low:.4f}–{high:.4f}")
    ax.axhline(mean, color=PURPLE, linewidth=1.2, label=f"mean {mean:.4f}")
    ax.axhline(0.5, color=GREY, linestyle=":", linewidth=1)
    ax.set(xlabel="Repetition seed", ylabel="Real–synthetic discriminator AUROC", ylim=(0.48, 0.82), xticks=seeds)
    ax.text(
        0.98,
        0.43,
        "Not membership inference",
        transform=ax.transAxes,
        ha="right",
        va="center",
        fontsize=7.5,
        color=DARK,
    )
    ax.legend(frameon=False, loc="lower left")
    style_axis(ax)
    panel(ax, "d")
    suffix = "" if final_names else "_preview"
    save(fig, output, f"fig5_overlap_distance_discriminator{suffix}", dpi, png_only=final_names)


def render_figure6(data_dir: Path, output: Path, dpi: int, final_names: bool) -> None:
    truth = read_tsv(data_dir, "fig6a_truth_conversion_classes.tsv")
    delivery = read_tsv(data_dir, "fig6b_delivery_observability_corrected.tsv")
    recount = read_tsv(data_dir, "fig6c_independent_read_count_pairs.tsv")
    exact = read_tsv(data_dir, "fig6d_public_exact_snv_vaf.tsv")
    public_summary = json.loads((ROOT / "data/zenodo_staging_v2_pending/public_read_validation_summary.json").read_text())
    fig, axes = plt.subplots(2, 2, figsize=(7.09, 5.91), constrained_layout=True)
    ax = axes[0, 0]
    truth = truth.sort_values("count", ascending=True)
    colors = [DARK, PURPLE, GREEN, SYNTHETIC, REAL]
    bars = ax.barh(truth["conversion_class"], truth["count"], color=colors)
    for bar, count, proportion in zip(bars, truth["count"], truth["proportion"]):
        ax.text(count + 180, bar.get_y() + bar.get_height() / 2, f"{count:,} ({proportion:.2%})", va="center", fontsize=7)
    ax.set(xlabel="Input variant rows", xlim=(0, 19000))
    ax.grid(axis="x", color=LIGHT, linewidth=0.5, alpha=0.55)
    panel(ax, "a")

    ax = axes[0, 1]
    delivery_order = ["all anchors", "diagnostic count >0", "valid ref/alt count >0", "exact SNV count >0", "exact SNV ALT >0"]
    delivery = delivery.set_index("observability_level").loc[delivery_order].reset_index()
    bars = ax.barh(np.arange(5), delivery["count"], color=[GREY, REAL, GREEN, PURPLE, SYNTHETIC])
    ax.set_yticks(np.arange(5), ["All anchors", "Diagnostic count >0", "Valid REF/ALT count >0", "Exact SNV count >0", "Exact SNV ALT >0"])
    ax.invert_yaxis()
    for bar, count, proportion in zip(bars, delivery["count"], delivery["proportion_of_all_anchors"]):
        ax.text(count + 28, bar.get_y() + bar.get_height() / 2, f"{count:,} ({proportion:.2%})", va="center", fontsize=7)
    ax.set(xlabel="Anchors (common denominator 2,241)", xlim=(0, 2600))
    ax.grid(axis="x", color=LIGHT, linewidth=0.5, alpha=0.55)
    panel(ax, "b")

    ax = axes[1, 0]
    for label, source, color in (("REF", "ref", REAL), ("ALT", "alt", SYNTHETIC)):
        grouped = recount.groupby([f"historical_{source}_count", f"independent_{source}_count"]).size().reset_index(name="multiplicity")
        ax.scatter(grouped[f"historical_{source}_count"], grouped[f"independent_{source}_count"],
                   s=20 + 9 * np.log1p(grouped["multiplicity"]), color=color, alpha=0.65, label=label,
                   edgecolors="white", linewidths=0.4)
    ax.plot([0, 9.5], [0, 9.5], color=GREY, linestyle=":", linewidth=1)
    ax.set(xlabel="Historical 21-mer count", ylabel="Independent count from public FASTQ",
           xlim=(-0.25, 9.5), ylim=(-0.25, 9.5))
    ax.text(0.97, 0.05, "183/183 matched", transform=ax.transAxes,
            ha="right", va="bottom", fontsize=7)
    ax.legend(frameon=False, loc="upper left")
    style_axis(ax)
    panel(ax, "c")

    ax = axes[1, 1]
    detected = exact[exact["alt_count"] > 0]
    not_detected = exact[exact["alt_count"] == 0]
    ax.scatter(not_detected["scaled_target_vaf"], not_detected["observed_vaf"],
               facecolors="none", edgecolors=PURPLE, marker="o", label="No ALT count", alpha=0.8)
    ax.scatter(detected["scaled_target_vaf"], detected["observed_vaf"],
               color=REAL, marker="o", label="ALT count >0", alpha=0.85)
    ax.plot([0, 0.55], [0, 0.55], color=GREY, linestyle=":", linewidth=1)
    ax.set(xlabel="Tumour-content-scaled target VAF", ylabel="Observed diagnostic VAF",
           xlim=(0, 0.32), ylim=(-0.025, 0.55))
    ax.text(0.97, 0.74,
            f"{len(detected)}/{len(exact)} with ALT count\n"
            f"Spearman rho={public_summary['exact_snv_scaled_target_vs_observed_spearman_rho']:.3f}; "
            f"p={public_summary['exact_snv_scaled_target_vs_observed_spearman_p']:.4f}",
            transform=ax.transAxes, ha="right", va="top", fontsize=7)
    ax.legend(frameon=False, loc="center right")
    style_axis(ax)
    panel(ax, "d")
    suffix = "" if final_names else "_preview"
    save(fig, output, f"fig6_spikein_read_validation{suffix}", dpi, png_only=final_names)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--dpi", type=int, default=200)
    parser.add_argument(
        "--final-names",
        action="store_true",
        help="Use publication filenames without the _preview suffix.",
    )
    args = parser.parse_args()
    configure()
    render_figure3(args.data_dir, args.output_dir, args.dpi, args.final_names)
    render_figure4(args.data_dir, args.output_dir, args.dpi, args.final_names)
    render_figure5(args.data_dir, args.output_dir, args.dpi, args.final_names)
    render_figure6(args.data_dir, args.output_dir, args.dpi, args.final_names)
    print(args.output_dir)


if __name__ == "__main__":
    main()
