#!/usr/bin/env python3
"""Recount published FASTQ 21-mers at preselected delivery-depth anchors.

Reference contexts are independently obtained from UCSC hg38. This checks a
bounded subset of row-to-file content links, not all variant realizations or the
historical FASTA/model bytes.
"""

import argparse
import csv
import gzip
import json
import tarfile
from collections import defaultdict
from pathlib import Path


def rows(path: Path, delimiter: str) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter=delimiter))


def count_fastq(source, patterns: list[tuple[bytes, bytes]]) -> tuple[list[list[int]], int]:
    counts = [[0, 0] for _ in patterns]
    reads = 0
    with gzip.GzipFile(fileobj=source) as stream:
        while header := stream.readline():
            sequence = stream.readline().strip().upper()
            separator = stream.readline()
            quality = stream.readline()
            if not (header.startswith(b"@") and separator.startswith(b"+") and
                    len(sequence) == len(quality.rstrip(b"\n")) == 100):
                raise ValueError(f"Malformed FASTQ at read {reads}")
            for index, (ref21, alt21) in enumerate(patterns):
                counts[index][0] += sequence.count(ref21)
                counts[index][1] += sequence.count(alt21)
            reads += 1
    return counts, reads


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tar", required=True, type=Path)
    parser.add_argument("--contexts", type=Path,
                        default=Path("data/zenodo_staging_v2_pending/hg38_independent_anchor_contexts.tsv"))
    parser.add_argument("--counts", type=Path,
                        default=Path("data/zenodo_staging_v2_pending/delivery_anchor_counts.csv"))
    parser.add_argument("--mapping", type=Path,
                        default=Path("data/zenodo_staging_v2_pending/fastq_patient_mapping_v2.csv"))
    parser.add_argument("--archive-report", type=Path,
                        default=Path("manuscript_workbench/v2/FASTQ_ARCHIVE_AUDIT.json"))
    parser.add_argument("--output-prefix", type=Path,
                        default=Path("manuscript_workbench/v2/INDEPENDENT_ANCHOR_READ_CHECK"))
    args = parser.parse_args()
    report = json.loads(args.archive_report.read_text())
    if not (report.get("full_audit") and report.get("archive_md5_match") and
            report.get("member_rows") == 2000 and not report.get("members_with_errors")):
        raise ValueError("Complete passing FASTQ archive audit is required")
    contexts = {(item["chrom"], item["one_based_pos"], item["alt"]): item
                for item in rows(args.contexts, "\t")}
    historical = [item for item in rows(args.counts, ",")
                  if int(item["ref_count"]) + int(item["alt_count"]) > 0]
    if len(historical) != 204 or len(contexts) != 146:
        raise ValueError("Unexpected preselected anchor set")
    mapping = {item["virtual_patient_id"]: item for item in rows(args.mapping, ",")}
    by_patient = defaultdict(list)
    for item in historical:
        patient = item["patient"]
        key = (item["chrom"], item["pos"], item["alt"])
        if patient not in mapping or key not in contexts:
            raise ValueError(f"Missing mapping or reference context: {patient}, {key}")
        by_patient[patient].append((item, contexts[key]))
    output = []
    with tarfile.open(args.tar, "r") as archive:
        for patient in sorted(by_patient):
            member = archive.getmember(mapping[patient]["archive_member_path"])
            source = archive.extractfile(member)
            if source is None:
                raise ValueError(f"Cannot read archive member for {patient}")
            pairs = by_patient[patient]
            patterns = [(item[1]["ref21"].encode(), item[1]["alt21"].encode())
                        for item in pairs]
            with source:
                recounted, reads = count_fastq(source, patterns)
            if reads != 200000:
                raise ValueError(f"Wrong FASTQ read count at {patient}: {reads}")
            for (prior, context), (ref_count, alt_count) in zip(pairs, recounted):
                valid = (context["ref"] in "ACGT" and context["alt"] in "ACGT" and
                         context["ref"] != context["alt"] and
                         set(context["ref21"]) <= set("ACGT"))
                prior_ref, prior_alt = int(prior["ref_count"]), int(prior["alt_count"])
                output.append({
                    "synthetic_record_id": mapping[patient]["synthetic_record_id"],
                    "virtual_patient_id": patient,
                    "archive_member_path": member.name,
                    "chrom": prior["chrom"],
                    "one_based_pos": prior["pos"],
                    "ref": context["ref"],
                    "alt": prior["alt"],
                    "ref21": context["ref21"],
                    "alt21": context["alt21"],
                    "historical_ref_count": prior_ref,
                    "historical_alt_count": prior_alt,
                    "independent_ref_count": ref_count,
                    "independent_alt_count": alt_count,
                    "context_valid": str(valid).lower(),
                    "historical_counts_match": str((prior_ref, prior_alt) == (ref_count, alt_count)).lower(),
                })
            if len(output) % 25 < len(pairs):
                print(f"Recounted {len(output)}/{len(historical)} anchor rows", flush=True)
    args.output_prefix.parent.mkdir(parents=True, exist_ok=True)
    detail = args.output_prefix.with_suffix(".tsv")
    with detail.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(output)
    summary = {
        "scope": "new independent UCSC hg38 21-mer recount of historically covered anchors",
        "reference_accession": "GCA_000001405.15",
        "historical_fasta_byte_identity_asserted": False,
        "preselected_historical_nonzero_anchor_rows": len(historical),
        "patients_recounted": len(by_patient),
        "valid_reference_context_rows": sum(item["context_valid"] == "true" for item in output),
        "reference_equals_alt_rows_excluded": sum(item["context_valid"] == "false" and item["ref"] == item["alt"] for item in output),
        "historical_count_pairs_matching": sum(item["historical_counts_match"] == "true" for item in output),
        "valid_context_count_pairs_matching": sum(item["context_valid"] == "true" and item["historical_counts_match"] == "true" for item in output),
        "historical_alt_positive_rows": sum(int(item["historical_alt_count"]) > 0 for item in output),
        "independently_alt_positive_rows": sum(int(item["independent_alt_count"]) > 0 for item in output),
        "interpretation_limit": "Preselected covered anchors only; no all-variant validation or proof of unique file identity.",
    }
    args.output_prefix.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    if (summary["valid_reference_context_rows"], summary["reference_equals_alt_rows_excluded"]) != (183, 21):
        raise SystemExit("Unexpected valid/excluded context split; inspect detail TSV")
    if summary["valid_context_count_pairs_matching"] != summary["valid_reference_context_rows"]:
        raise SystemExit("Independent read counts differ from historical counts; inspect detail TSV")


if __name__ == "__main__":
    main()
