# V2 verification code snapshot (local candidate)

This snapshot contains the bounded checks used for the ScienceDB V2 candidate. It verifies file identities, CSV row-to-FASTQ links, per-member FASTQ integrity, and selected 21-mer counts. It does not regenerate the historical CTGAN model or prove that every input variant was injected.

The included code is distributed under the accompanying MIT `LICENSE`.

Requires Python 3.11 or later and the packages in `requirements.txt`. All commands below use paths to files in the downloaded dataset; no private source table or historical simulator environment is required for these checks.

```bash
python audit_fastq_archive.py \
  --tar /path/to/synthetic_msk_impact_2017_reads.tar \
  --mapping /path/to/V2/fastq_patient_mapping.csv \
  --manifest /path/to/V1/MANIFEST.md5 \
  --output-prefix ./FASTQ_ARCHIVE_AUDIT

python verify_fastq_anchor_signatures.py \
  --tar /path/to/synthetic_msk_impact_2017_reads.tar \
  --contexts /path/to/V2/hg38_independent_anchor_contexts.tsv \
  --counts /path/to/V2/delivery_anchor_counts.csv \
  --mapping /path/to/V2/fastq_patient_mapping_v2.csv \
  --archive-report ./FASTQ_ARCHIVE_AUDIT.json \
  --output-prefix ./INDEPENDENT_ANCHOR_READ_CHECK

python prepare_public_read_validation_figure_data.py \
  --candidate /path/to/V2 \
  --read-check-prefix ./INDEPENDENT_ANCHOR_READ_CHECK \
  --workbench-figure-dir ./recomputed_figure_data

python check_v2_release_candidate.py \
  --candidate /path/to/V2 \
  --cohort /path/to/synthetic_msk_impact_2017_cohort.csv \
  --archive-report ./FASTQ_ARCHIVE_AUDIT.json \
  --read-check ./INDEPENDENT_ANCHOR_READ_CHECK.json \
  --output ./V2_CANDIDATE_GATE.json
```

`correct_delivery_anchor_validation.py --candidate /path/to/V2` regenerates the corrected delivery-depth summary from the saved counts, truth and UCSC contexts. `fetch_hg38_anchor_contexts.py` records how the independent contexts were requested. The reference is UCSC hg38 initial GRCh38 primary sequence, accession GCA_000001405.15; historical simulator FASTA byte identity is not asserted. The figure script writes two derived panels into the candidate directory; run it on a writable copy of the V2 download. A full archive audit and 21-mer recount may take substantial CPU time and disk space.

The public V1 manifest had a duplicate line for the tar checksum; the verification script reads the published value and checks the tar and each member independently. A passing local audit is distinct from verifying the eventual public V2 objects through a fresh anonymous download.
