#!/usr/bin/env python3
"""Independently check the local V2 candidate's files and record relationships.

This is a prepublication gate. A pass does not mean ScienceDB V2 exists or that
every configured variant allele has been confirmed in reads.
"""

import argparse
import csv
import hashlib
import json
import tarfile
from collections import Counter
from pathlib import Path


EXPECTED_CSV_SHA256 = "bfa7712046474595a96ed2b9bf3fbce4abcd907d4c0038b3f7d35f87dd4847f4"
EXPECTED_TAR_MD5 = "57cbf75540c94b38c033b6e0aac70bc1"
EXPECTED_FIDELITY_SHA256 = "3e15da2c30096124041d7b742a1f05ad7763583242600fc9feedc0f38efad33f"


def digest(path: Path, algorithm: str) -> str:
    value = hashlib.new(algorithm)
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def table(path: Path, delimiter: str) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter=delimiter))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=Path("data/zenodo_staging_v2_pending"))
    parser.add_argument("--cohort", type=Path,
                        default=Path("data/zenodo_staging/synthetic_msk_impact_2017_cohort.csv"))
    parser.add_argument("--archive-report", type=Path,
                        default=Path("manuscript_workbench/v2/FASTQ_ARCHIVE_AUDIT.json"))
    parser.add_argument("--read-check", type=Path,
                        default=Path("manuscript_workbench/v2/INDEPENDENT_ANCHOR_READ_CHECK.json"))
    parser.add_argument("--output", type=Path,
                        default=Path("manuscript_workbench/v2/V2_CANDIDATE_GATE.json"))
    args = parser.parse_args()
    require(args.archive_report.exists(), "Full FASTQ archive audit is required")
    require(args.read_check.exists(), "Independent public-read recount is required")
    root = args.candidate
    csv_hash = digest(args.cohort, "sha256")
    require(csv_hash == EXPECTED_CSV_SHA256, "Cohort CSV has unexpected SHA-256")
    cohort = table(args.cohort, ",")
    index = table(root / "sample_index.tsv", "\t")
    mapping = table(root / "fastq_patient_mapping.csv", ",")
    mapping_v2 = table(root / "fastq_patient_mapping_v2.csv", ",")
    truth = table(root / "fastq_spikein_truth.tsv", "\t")
    flags = table(root / "variant_quality_flags.tsv", "\t")
    fallback_contexts = table(root / "hg38_fallback_contexts.tsv", "\t")
    correction = json.loads((root / "delivery_anchor_correction.json").read_text())
    errors = table(root / "simulator_error_flags.tsv", "\t")
    delivery_counts = table(root / "delivery_anchor_counts.csv", ",")
    require(len(cohort) == len(index) == 10328, "CSV/index count mismatch")
    require(len(mapping) == len(mapping_v2) == 2000, "Mapping count mismatch")
    require(len(truth) == len(flags) == 26790, "Truth/flags count mismatch")
    require(len(fallback_contexts) == 378 and
            sum(item["ref"] == item["alt"] for item in fallback_contexts) == 97,
            "Fallback reference-context audit mismatch")
    fallback_by_locus = {(item["chrom"], item["one_based_pos"], item["alt"]): item
                         for item in fallback_contexts}
    no_change_flags = [item for item in flags if item["conversion_class"] == "gene_fallback_pm" and
                       item["benchmark_validation_status"] == "reference_equals_alt_on_independent_hg38"]
    require(len(no_change_flags) == 1074 and
            len({item["virtual_patient_id"] for item in no_change_flags}) == 731,
            "Reference-equals-ALT fallback flag mismatch")
    for source, flag in zip(truth, flags):
        if source["conversion_class"] != "gene_fallback_pm":
            continue
        locus = (source["chrom"], source["position_or_start"], source["alt_or_inserted_base"])
        context = fallback_by_locus.get(locus)
        require(context is not None and flag["reference_allele"] == context["ref"] and
                flag["reference_source"] == context["reference_source"],
                f"Fallback reference context mismatch: {flag['variant_id']}")
        require((flag["benchmark_validation_status"] == "reference_equals_alt_on_independent_hg38") ==
                (context["ref"] == context["alt"]),
                f"Fallback no-change status mismatch: {flag['variant_id']}")
    require(len(delivery_counts) == 2241 and
            len({item["patient"] for item in delivery_counts}) == 495,
            "Historical delivery-anchor count table mismatch")
    delivery_observed = {
        "all anchors": len(delivery_counts),
        "locus covered": sum(int(item["ref_count"]) + int(item["alt_count"]) > 0
                             for item in delivery_counts),
        "ALT detected": sum(int(item["alt_count"]) > 0 for item in delivery_counts),
        "depth at least 2": sum(int(item["ref_count"]) + int(item["alt_count"]) >= 2
                                for item in delivery_counts),
    }
    delivery_figure = table(root / "figure_data/fig6b_delivery_observability.tsv", "\t")
    require({item["observability_level"]: int(item["count"]) for item in delivery_figure} ==
            delivery_observed, "Figure 5 delivery-depth counts differ from saved anchor data")
    corrected_figure = table(root / "figure_data/fig6b_delivery_observability_corrected.tsv", "\t")
    require({item["observability_level"]: int(item["count"]) for item in corrected_figure} == {
        "all anchors": 2241, "diagnostic count >0": 204, "valid ref/alt count >0": 183,
        "exact SNV count >0": 138, "exact SNV ALT >0": 11},
        "Corrected delivery-depth figure mismatch")
    require(correction["covered_reference_equals_alt_fallback_rows_excluded"] == 21 and
            correction["alt_positive_valid_reference_alt_rows"] == 14 and
            correction["all_exact_snv_anchor_rows"] == 1675 and
            correction["depth_ge2_exact_snv_rows"] == 65,
            "Corrected delivery-depth statistics mismatch")
    minisim = table(root / "minisim_anchor_provenance.tsv", "\t")
    minisim_figure = table(root / "figure_data/fig6cd_exact_snv_minisim.tsv", "\t")
    require(len(minisim) == 102 and len(minisim_figure) == 80,
            "Mini-simulation provenance or plotted subset has unexpected length")
    primary = [item for item in minisim if item["provenance"] == "exact_snv" and
               item["ambiguous_duplicate_locus"] == "False"]
    require(len(primary) == 80 and
            {(item["patient"], item["chrom"], item["pos"], item["alt"])
             for item in primary} ==
            {(item["patient"], item["chrom"], item["pos"], item["alt"])
             for item in minisim_figure},
            "Historical mini-simulation subset differs from saved provenance")
    historical_counts = Path("data/synthetic_2017/evaluation/aggregate_anchor_detail.csv")
    if historical_counts.exists():
        require(digest(root / "delivery_anchor_counts.csv", "sha256") ==
                digest(historical_counts, "sha256"),
                "Delivery-anchor table differs from archived local evidence")

    mapped_rows = set()
    mapped_names = set()
    for virtual, (old, new) in enumerate(zip(mapping, mapping_v2)):
        name = f"virtual_pt_{virtual:04d}"
        require(old["virtual_patient_id"] == new["virtual_patient_id"] == name,
                f"Virtual-patient order mismatch at {virtual}")
        require(all(old[key] == new[key] for key in old), f"V2 mapping altered historical row {virtual}")
        row = int(old["synthetic_csv_zero_based_row"])
        filename = f"{name}.fastq.gz"
        require(0 <= row < len(cohort), f"Out-of-bounds CSV row at {name}")
        require(row not in mapped_rows and filename not in mapped_names, "Duplicate row or FASTQ name")
        require(old["fastq_filename"] == new["archive_member_path"] == filename,
                f"Archive path mismatch at {name}")
        require(int(old["synthetic_csv_one_based_data_row"]) == row + 1 and
                int(old["synthetic_csv_file_line_with_header"]) == row + 2 and
                int(old["simulation_seed"]) == virtual + 42,
                f"Row/seed convention mismatch at {name}")
        require(new["synthetic_record_id"] == f"SYN2017_{row:05d}",
                f"Stable ID mismatch at {name}")
        mapped_rows.add(row)
        mapped_names.add(filename)

    for number, item in enumerate(index):
        require(item["synthetic_record_id"] == f"SYN2017_{number:05d}" and
                item["synthetic_csv_zero_based_row"] == str(number) and
                item["synthetic_csv_one_based_data_row"] == str(number + 1) and
                item["synthetic_csv_sha256"] == csv_hash and
                item["synthetic_csv_filename"] == args.cohort.name,
                f"Sample index mismatch at {number}")
        require((item["has_fastq"] == "true") == (number in mapped_rows),
                f"has_fastq mismatch at {number}")
    by_row = {int(item["synthetic_csv_zero_based_row"]): item for item in mapping}
    for number in mapped_rows:
        require(index[number]["virtual_patient_id"] == by_row[number]["virtual_patient_id"],
                f"Index-to-mapping mismatch at {number}")

    variant_counts = Counter()
    class_counts: dict[str, Counter] = {}
    expected_ids = set()
    for item in truth:
        patient = item["virtual_patient_id"]
        variant_id = f"{patient}_v{int(item['input_variant_index']):03d}"
        require(variant_id not in expected_ids, f"Duplicate variant ID {variant_id}")
        expected_ids.add(variant_id)
        variant_counts[patient] += 1
        class_counts.setdefault(patient, Counter())[item["conversion_class"]] += 1
    for item in mapping:
        patient = item["virtual_patient_id"]
        require(variant_counts[patient] == int(item["input_variant_count"]),
                f"Truth count mismatch at {patient}")
        for kind in ("exact_snv", "gene_fallback_pm", "amplification_cna",
                     "heuristic_indel", "dropped_unmapped"):
            require(class_counts.get(patient, Counter())[kind] == int(item[f"{kind}_count"]),
                    f"Truth class count mismatch at {patient}: {kind}")
    flag_ids = [item["variant_id"] for item in flags]
    require(len(set(flag_ids)) == len(flag_ids) and set(flag_ids) == expected_ids,
            "Variant quality flags do not cover truth exactly")
    require(sum(int(item["log_occurrences"]) for item in errors) == 86 and len(errors) == 80,
            "Simulator error tally mismatch")

    with tarfile.open(root / "fastq_spikein_specs.tar.gz", "r:gz") as archive:
        members = archive.getmembers()
    require(len(members) == 6000 and all(item.isfile() for item in members),
            "Specification archive does not contain 6,000 files")
    require(len({item.name for item in members}) == 6000, "Specification archive has duplicate paths")
    expected_specs = {f"variant_specs/virtual_pt_{i:04d}/variants.{kind}"
                      for i in range(2000) for kind in ("pm", "indel", "cna")}
    require({item.name for item in members} == expected_specs,
            "Specification archive member paths do not match mapping")

    manifest = root / "MANIFEST_V2.md5"
    if not manifest.exists():
        manifest = root / "MANIFEST_V2_PENDING.md5"
    require(manifest.exists(), "No V2 manifest found")
    entries = {}
    for line in manifest.read_text().splitlines():
        checksum, path = line.split(None, 1)
        require(path not in entries, f"Duplicate manifest entry: {path}")
        entries[path] = checksum
    files = {path.relative_to(root).as_posix() for path in root.rglob("*")
             if path.is_file() and path != manifest}
    require(files == set(entries), "Candidate manifest file set is incomplete or stale")
    for relative, checksum in entries.items():
        require(digest(root / relative, "md5") == checksum,
                f"Candidate manifest checksum mismatch: {relative}")

    audit = None
    archive_verified = False
    if args.archive_report.exists():
        audit = json.loads(args.archive_report.read_text())
        archive_verified = (audit.get("full_audit") is True and
                            audit.get("archive_md5_match") is True and
                            audit.get("archive_md5") == EXPECTED_TAR_MD5 and
                            audit.get("member_rows") == 2000 and
                            audit.get("unique_member_names") == 2000 and
                            audit.get("ordered_names_match") is True and
                            audit.get("missing_mapping_members") == [] and
                            audit.get("unmapped_members") == [] and
                            audit.get("members_with_errors") == [] and
                            audit.get("all_members_200000_reads") is True)
        require(archive_verified, "Archive report exists but does not pass full audit")
    statuses = Counter(item["fastq_audit_status"] for item in mapping_v2)
    if archive_verified:
        details = {item["name"]: item for item in table(args.archive_report.with_suffix(".tsv"), "\t")}
        require(len(details) == 2000, "Archive detail row count mismatch")
        for item in mapping_v2:
            detail = details[item["archive_member_path"]]
            require(item["fastq_audit_status"] == "verified" and
                    item["fastq_md5"] == detail["md5"] and
                    item["fastq_compressed_bytes"] == detail["compressed_bytes"] and
                    item["read_count"] == detail["reads"] == "200000" and
                    item["read_length_bp"] == "100",
                    f"Mapping audit fields mismatch: {item['archive_member_path']}")
    else:
        require(statuses == {"pending_full_archive_audit": 2000} and
                all(not item["fastq_md5"] for item in mapping_v2),
                "Mapping claims verified FASTQ without a complete audit")

    read_check = None
    if args.read_check.exists():
        read_check = json.loads(args.read_check.read_text())
        require(archive_verified and
                read_check["valid_reference_context_rows"] == 183 and
                read_check["reference_equals_alt_rows_excluded"] == 21 and
                read_check["valid_context_count_pairs_matching"] == 183,
                "Independent anchor-read check is incomplete or does not match")
        candidate_read_check = json.loads((root / "INDEPENDENT_ANCHOR_READ_CHECK.json").read_text())
        require(candidate_read_check == read_check,
                "Candidate independent-read summary differs from verified source")
        source_pairs = table(args.read_check.with_suffix(".tsv"), "\t")
        require(source_pairs == table(root / "INDEPENDENT_ANCHOR_READ_CHECK.tsv", "\t") and
                len(source_pairs) == 204,
                "Candidate independent-read detail differs from verified source")
        public_summary = json.loads((root / "public_read_validation_summary.json").read_text())
        panel_c = table(root / "figure_data/fig6c_independent_read_count_pairs.tsv", "\t")
        panel_d = table(root / "figure_data/fig6d_public_exact_snv_vaf.tsv", "\t")
        require(len(panel_c) == public_summary["valid_covered_anchor_count_pairs_matching"] == 183 and
                len(panel_d) == public_summary["exact_snv_depth_ge2_rows"] == 65 and
                public_summary["exact_snv_alt_positive_depth_ge2_rows"] ==
                sum(int(item["alt_count"]) > 0 for item in panel_d) == 5 and
                all(item["historical_ref_count"] == item["independent_ref_count"] and
                    item["historical_alt_count"] == item["independent_alt_count"] for item in panel_c),
                "Public-read panels or summary do not match the independent recount")
    retained = table(root / "V2_RETAINED_CORE_ASSETS.tsv", "\t")
    required = {item["required_v2_filename"]: item for item in retained}
    require(set(required) == {"synthetic_msk_impact_2017_cohort.csv",
                             "synthetic_msk_impact_2017_reads.tar",
                             "tv_2017_statistical_fidelity.json"},
            "Retained core asset inventory is incomplete")
    require(required["synthetic_msk_impact_2017_cohort.csv"]["sha256"] == csv_hash and
            required["synthetic_msk_impact_2017_cohort.csv"]["bytes"] == str(args.cohort.stat().st_size),
            "Retained CSV identity mismatch")
    require(required["tv_2017_statistical_fidelity.json"]["sha256"] == EXPECTED_FIDELITY_SHA256,
            "Retained fidelity JSON identity mismatch")
    if archive_verified:
        tar_entry = required["synthetic_msk_impact_2017_reads.tar"]
        require(tar_entry["bytes"] == str(audit["archive_bytes"]) and
                tar_entry["md5"] == audit["archive_md5"] and
                tar_entry["sha256"] == audit["archive_sha256"],
                "Retained FASTQ tar identity mismatch")

    result = {
        "scope": "local V2 release candidate; no public V2 download verified",
        "cohort_csv_sha256": csv_hash,
        "cohort_rows": len(cohort),
        "mapped_fastq_rows": len(mapping),
        "unmapped_table_rows": len(cohort) - len(mapping),
        "input_truth_rows": len(truth),
        "historical_delivery_anchor_rows": len(delivery_counts),
        "fallback_reference_equals_alt_rows": len(no_change_flags),
        "corrected_delivery_exact_snv_alt_rows": correction["alt_positive_exact_snv_rows"],
        "historical_minisim_rows": len(minisim),
        "historical_unambiguous_exact_snv_rows": len(primary),
        "specification_files": len(members),
        "simulator_error_occurrences": sum(int(item["log_occurrences"]) for item in errors),
        "candidate_manifest_files": len(entries),
        "archive_fully_verified": archive_verified,
        "independent_anchor_read_check_passed": read_check is not None,
        "public_exact_snv_depth_ge2_rows": 65 if read_check else None,
        "mapping_audit_status_counts": dict(statuses),
        "local_structure_gate": "PASS",
        "public_v2_gate": "NOT_TESTED",
        "read_level_variant_gate": "BOUNDED_ANCHOR_CHECK_PASS" if read_check else "NOT_TESTED",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
