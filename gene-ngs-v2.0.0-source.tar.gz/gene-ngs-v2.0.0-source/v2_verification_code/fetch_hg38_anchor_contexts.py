#!/usr/bin/env python3
"""Fetch UCSC hg38 21-bp contexts for covered anchors or fallback PM loci.

This creates a new, versioned reference basis for independent FASTQ checks.
It does not assert byte identity with the unavailable historical FASTA.
"""

import argparse
import csv
import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests


API = "https://api.genome.ucsc.edu/getData/sequence"
local = threading.local()


def session() -> requests.Session:
    if not hasattr(local, "session"):
        local.session = requests.Session()
    return local.session


def fetch(locus: tuple[str, int, str]) -> dict[str, str]:
    chrom, pos, alt = locus
    params = {"genome": "hg38", "chrom": chrom, "start": pos - 11, "end": pos + 10}
    for attempt in range(8):
        try:
            response = session().get(API, params=params, timeout=30)
            if response.status_code == 429:
                time.sleep(min(120, 5 * (attempt + 1)))
                continue
            response.raise_for_status()
            value = response.json()
            dna = value["dna"].upper()
            if (value.get("genome"), value.get("chrom"), value.get("start"),
                value.get("end"), len(dna)) != ("hg38", chrom, pos - 11, pos + 10, 21):
                raise ValueError(f"Unexpected UCSC response at {locus}: {value}")
            ref = dna[10]
            return {"chrom": chrom, "one_based_pos": str(pos), "alt": alt,
                    "ref": ref, "ref21": dna, "alt21": dna[:10] + alt + dna[11:],
                    "reference_source": "UCSC hg38 initial GRCh38 primary sequence",
                    "reference_accession": "GCA_000001405.15"}
        except (requests.RequestException, json.JSONDecodeError):
            if attempt == 7:
                raise
            time.sleep(min(30, 2 ** attempt))
    raise RuntimeError(f"UCSC rate limit persisted at {locus}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--counts", type=Path,
                        default=Path("data/zenodo_staging_v2_pending/delivery_anchor_counts.csv"))
    parser.add_argument("--truth", type=Path,
                        default=Path("data/zenodo_staging_v2_pending/fastq_spikein_truth.tsv"))
    parser.add_argument("--scope", choices=("covered", "fallback"), default="covered")
    parser.add_argument("--output", type=Path,
                        default=Path("data/zenodo_staging_v2_pending/hg38_independent_anchor_contexts.tsv"))
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    if args.scope == "covered":
        with args.counts.open(newline="") as stream:
            counts = list(csv.DictReader(stream))
        covered = [item for item in counts if int(item["ref_count"]) + int(item["alt_count"]) > 0]
        loci = sorted({(item["chrom"], int(item["pos"]), item["alt"]) for item in covered})
        if len(counts) != 2241 or len(covered) != 204 or len(loci) != 146:
            raise ValueError("Unexpected historical count input; inspect before fetching contexts")
    else:
        with args.truth.open(newline="") as stream:
            truth = list(csv.DictReader(stream, delimiter="\t"))
        fallback = [item for item in truth if item["conversion_class"] == "gene_fallback_pm"]
        loci = sorted({(item["chrom"], int(item["position_or_start"]), item["alt_or_inserted_base"])
                       for item in fallback})
        if len(fallback) != 4953 or len(loci) != 378:
            raise ValueError("Unexpected fallback truth input; inspect before fetching contexts")
    existing = {}
    if args.output.exists():
        with args.output.open(newline="") as stream:
            existing = {(item["chrom"], int(item["one_based_pos"]), item["alt"]): item
                        for item in csv.DictReader(stream, delimiter="\t")}
    result = dict(existing)
    pending = [locus for locus in loci if locus not in result]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(fetch, locus): locus for locus in pending}
        for future in as_completed(futures):
            locus = futures[future]
            result[locus] = future.result()
            if len(result) % 25 == 0 or len(result) == len(loci):
                print(f"Fetched {len(result)}/{len(loci)} contexts", flush=True)
                with args.output.open("w", newline="") as stream:
                    writer = csv.DictWriter(stream, fieldnames=list(next(iter(result.values()))), delimiter="\t")
                    writer.writeheader()
                    writer.writerows(result[key] for key in sorted(result))
    with args.output.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(next(iter(result.values()))), delimiter="\t")
        writer.writeheader()
        writer.writerows(result[key] for key in sorted(result))
    if len(result) != len(loci):
        raise ValueError("Incomplete UCSC contexts")
    problematic = [item for item in result.values()
                   if item["ref"] == item["alt"] or set(item["ref21"]) - set("ACGT")]
    print({"loci": len(result), "reference_or_allele_problem_rows": len(problematic),
           "output": str(args.output)})


if __name__ == "__main__":
    main()
